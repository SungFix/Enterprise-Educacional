# Enterprise Educacional

Plataforma educacional estática, responsiva e interativa para aprender desenvolvimento e programação com aulas extensas, exemplos, exercícios, desafios, projetos, progresso local, Glossário, Busca e Playground HTML/CSS/JavaScript/Python.

## Conteúdo atual

- **HTML:** 12 módulos e 164 aulas/conteúdos;
- **CSS:** 18 módulos e 195 aulas/conteúdos;
- **JavaScript:** 25 módulos e 262 aulas/conteúdos;
- **Python:** 24 módulos e 202 aulas/conteúdos;
- **Total:** 823 aulas/conteúdos em 79 módulos;
- **Exercícios:** 291;
- **Desafios:** 24;
- **Projetos:** 31;
- **Glossário:** 74 termos.

## Experiência premium

A interface foi refinada para usar uma escala mais rica de preto, grafite, cinza e prata no Dark Mode e branco suave, off-white e cinzas neutros no Light Mode. O layout continua desktop-first, mas adapta grids, navegação, aulas, exercícios, projetos e Playground para tablet e celular.

Principais melhorias atuais:

- Home com hierarquia mais forte, painel de código, métricas reais e recomendação de próximo passo;
- cards diferentes para trilhas, recursos, projetos e desafios, sem repetir a mesma composição em todo o produto;
- Header com estado ativo, Busca central e atalho **Ctrl/Cmd + K**;
- Trilhas alimentadas pelos 823 conteúdos reais e com próximo conteúdo/progresso por tecnologia;
- Sistema de aulas usando `content-data.js`, sidebar organizada por módulos, índice contextual, tempo estimado, conteúdo aprofundado, Glossário contextual, **modo foco, aulas salvas, notas por aula**, atalhos Alt+←/→ e navegação anterior/próxima;
- exercícios com tentativas persistidas, status de conclusão e feedback educacional;
- projetos com checklist persistente, progresso por etapas, critérios de conclusão e extensões;
- desafios com requisitos, dicas progressivas, solução oficial e conclusão persistente;
- Playground com HTML/CSS/JavaScript e **Python 3 real via Pyodide**, presets Web/Python, console/terminal recolhível, `stdin` para `input()`, carregamento automático de pacotes compatíveis, persistência, linhas numeradas, status do editor, preview desktop/tablet/mobile, **execução do resultado em tela cheia**, modo de editor em tela cheia, tabs acessíveis, `Ctrl/Cmd + Enter`, `Ctrl/Cmd + S`, autoindentação e redimensionamento entre editor e resultado no desktop;
- Glossário redesenhado com busca, filtros por categoria e letra, contagem de resultados, navegação visual, aulas relacionadas, termos relacionados e cópia rápida de definição;
- Progresso com visão geral, progresso por trilha, sequência de estudo, atividade recente, recomendação, aulas salvas e conquistas discretas;
- 404 integrada à identidade do produto;
- estados vazios mais úteis e foco visível em componentes interativos.

## Integração do aprendizado

- Trilhas → Módulos → Aulas utilizam a mesma base de dados;
- concluir aulas afeta progresso por trilha e progresso geral;
- exercícios, projetos e desafios também entram no progresso geral;
- aulas HTML/CSS/JavaScript com configuração de editor e exemplos Python podem abrir o código diretamente no Playground;
- Glossário referencia aulas relacionadas;
- Busca global indexa trilhas, módulos, aulas, exercícios, desafios, projetos e Glossário.

## Branding

Assets principais:

- `assets/branding/enterprise-symbol.svg`
- `assets/branding/enterprise-logo-horizontal.svg`
- `assets/branding/favicon.svg` — novo símbolo `<E>` geométrico usado como ícone do site

## Estrutura

- `index.html` — estrutura global e áreas principais;
- `styles.css` — Design System, Dark/Light, componentes e responsividade;
- `content-data.js` — currículo completo, aulas, exercícios, desafios, projetos e Glossário;
- `app.js` — roteamento hash, renderização, persistência, progresso, Busca, Glossário, mecânicas das aulas e Playground Web/Python;
- `assets/branding/` — identidade vetorial e favicon.

## Executar localmente

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.

Não existe etapa de build: o projeto é entregue como HTML/CSS/JavaScript estático e é compatível com hospedagem estática, incluindo GitHub Pages.


## Editor Python

A aba Python usa **Pyodide 0.27.7** carregado sob demanda a partir do CDN oficial via jsDelivr. O código roda em um Web Worker separado da interface. A primeira execução precisa de conexão com a internet para baixar o runtime; depois o Worker permanece carregado durante a sessão.

Recursos atuais:

- Python 3 no navegador;
- `print()` em terminal próprio;
- erros e `stderr` no mesmo terminal;
- `input()` usando o painel de `stdin`;
- imports de pacotes compatíveis com Pyodide carregados automaticamente quando possível;
- botão para interromper a execução encerrando o Worker;
- exemplos Python das aulas podem abrir diretamente no Playground.

## Refinamentos recentes

- console do Playground pode ser ocultado e reaberto sem perder a saída;
- mensagens recebidas enquanto o console está recolhido geram um contador discreto;
- o botão **Tela cheia** executa o código e abre somente o resultado (ou o terminal Python) em fullscreen;
- o editor mantém uma opção separada de tela cheia para quem quiser programar com mais espaço;
- o Glossário ganhou filtros por categoria, lista mais legível e uma página de termo mais rica;
- o símbolo e favicon foram substituídos por uma marca geométrica mais simples e legível em tamanhos pequenos.


## Atualizações recentes

- contraste do Light Mode reforçado para telas com brilho alto; superfícies agora usam uma escala quente de creme, bege e cinza-amarronzado sem perder a identidade neutra
