# Enterprise Educacional

Plataforma educacional estática, responsiva e interativa para aprender desenvolvimento e programação com aulas extensas, exemplos, exercícios, desafios, projetos, progresso local, Glossário, Busca e Playground HTML/CSS/JavaScript.

## Conteúdo atual

- **HTML:** 12 módulos e 164 aulas/conteúdos;
- **CSS:** 18 módulos e 195 aulas/conteúdos;
- **JavaScript:** 25 módulos e 262 aulas/conteúdos;
- **Python:** 24 módulos e 202 aulas/conteúdos;
- **Total:** 823 aulas/conteúdos em 79 módulos;
- **Exercícios:** 291;
- **Desafios:** 24;
- **Projetos:** 31;
- **Glossário:** 74 termos.

## Experiência premium

A interface foi refinada para usar uma escala mais rica de preto, grafite, cinza e prata no Dark Mode e branco suave, off-white e cinzas neutros no Light Mode. O layout continua desktop-first, mas adapta grids, navegação, aulas, exercícios, projetos e Playground para tablet e celular.

Principais melhorias atuais:

- Home com hierarquia mais forte, painel de código, métricas reais e recomendação de próximo passo;
- cards diferentes para trilhas, recursos, projetos e desafios, sem repetir a mesma composição em todo o produto;
- Header com estado ativo, Busca central e atalho **Ctrl/Cmd + K**;
- Trilhas alimentadas pelos 823 conteúdos reais e com próximo conteúdo/progresso por tecnologia;
- Sistema de aulas usando `content-data.js`, sidebar organizada por módulos, índice contextual, tempo estimado, conteúdo aprofundado, Glossário contextual e navegação anterior/próxima;
- exercícios com tentativas persistidas, status de conclusão e feedback educacional;
- projetos com checklist persistente, progresso por etapas, critérios de conclusão e extensões;
- desafios com requisitos, dicas progressivas, solução oficial e conclusão persistente;
- Playground com presets, console de `log`/`warn`/`error`, persistência, tela cheia, tabs acessíveis, `Ctrl/Cmd + Enter` e redimensionamento entre editor e resultado no desktop;
- Glossário com busca, letras, aulas relacionadas e navegação entre termos;
- Progresso com visão geral, progresso por trilha, atividade recente, recomendação e conquistas discretas;
- 404 integrada à identidade do produto;
- estados vazios mais úteis e foco visível em componentes interativos.

## Integração do aprendizado

- Trilhas → Módulos → Aulas utilizam a mesma base de dados;
- concluir aulas afeta progresso por trilha e progresso geral;
- exercícios, projetos e desafios também entram no progresso geral;
- aulas HTML/CSS/JavaScript com configuração de editor podem abrir exemplos diretamente no Playground;
- Glossário referencia aulas relacionadas;
- Busca global indexa trilhas, módulos, aulas, exercícios, desafios, projetos e Glossário.

## Branding

Assets principais:

- `assets/branding/enterprise-symbol.svg`
- `assets/branding/enterprise-logo-horizontal.svg`
- `assets/branding/favicon.svg`

## Estrutura

- `index.html` — estrutura global e áreas principais;
- `styles.css` — Design System, Dark/Light, componentes e responsividade;
- `content-data.js` — currículo completo, aulas, exercícios, desafios, projetos e Glossário;
- `app.js` — roteamento hash, renderização, persistência, progresso, Busca, Glossário e Playground;
- `assets/branding/` — identidade vetorial e favicon.

## Executar localmente

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.

Não existe etapa de build: o projeto é entregue como HTML/CSS/JavaScript estático e é compatível com hospedagem estática, incluindo GitHub Pages.
