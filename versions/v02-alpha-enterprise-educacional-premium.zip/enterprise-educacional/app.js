const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

const DATA = window.EE_CONTENT || { courses: [], lessons: [], exercises: [], challenges: [], projects: [], glossary: [] };
const courses = DATA.courses || [];
const lessons = DATA.lessons || [];
const exercises = DATA.exercises || [];
const challenges = DATA.challenges || [];
const projects = DATA.projects || [];
const glossary = [...(DATA.glossary || [])].sort((a, b) => a.term.localeCompare(b.term, 'pt-BR'));

const courseById = new Map(courses.map(course => [course.id, course]));
const lessonById = new Map(lessons.map(lesson => [lesson.id, lesson]));
const glossaryByTerm = new Map(glossary.map(term => [term.term.toLocaleLowerCase('pt-BR'), term]));
const lessonsByCourse = new Map(courses.map(course => [course.id, lessons.filter(lesson => lesson.courseId === course.id).sort((a,b) => (a.order ?? 0) - (b.order ?? 0))]));

const defaultPlayground = {
  html: `<main class="card">\n  <span class="tag">Enterprise Educacional</span>\n  <h1>Seu código, seu resultado.</h1>\n  <p>Edite este exemplo e clique em Executar.</p>\n  <button id="action">Testar JavaScript</button>\n</main>`,
  css: `body {\n  margin: 0;\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  font-family: system-ui, sans-serif;\n  background: #f2f2f2;\n  color: #171717;\n}\n.card {\n  width: min(520px, 86vw);\n  padding: 32px;\n  border: 1px solid #d5d5d5;\n  border-radius: 18px;\n  background: white;\n  box-shadow: 0 16px 40px rgba(0,0,0,.08);\n}\n.tag { font-size: 12px; color: #666; }\nbutton { padding: 10px 14px; cursor: pointer; }`,
  js: `document.querySelector('#action').addEventListener('click', () => {\n  document.querySelector('h1').textContent = 'Funcionou!';\n  console.log('Evento executado com sucesso.');\n});`
};

const playgroundPresets = {
  default: { label: 'Exemplo inicial', ...defaultPlayground },
  blank: { label: 'Página vazia', html: '<main>\n  <h1>Comece por aqui</h1>\n</main>', css: 'body { font-family: system-ui, sans-serif; padding: 32px; }', js: '' },
  card: { label: 'Card responsivo', html: '<article class="profile">\n  <span>Perfil</span>\n  <h1>Marina Costa</h1>\n  <p>Estudante de desenvolvimento web.</p>\n</article>', css: 'body { margin: 0; min-height: 100vh; display: grid; place-items: center; font-family: system-ui; background: #ececec; }\n.profile { width: min(420px, 84vw); padding: 28px; background: white; border: 1px solid #d2d2d2; border-radius: 16px; }\n.profile span { color: #666; font-size: 12px; }', js: '' },
  form: { label: 'Formulário', html: '<form id="contact">\n  <label>Nome <input name="nome" required></label>\n  <button>Enviar</button>\n  <p id="message"></p>\n</form>', css: 'body { font-family: system-ui; padding: 32px; }\nform { max-width: 420px; display: grid; gap: 16px; }\nlabel { display: grid; gap: 6px; }\ninput, button { padding: 10px 12px; font: inherit; }', js: `document.querySelector('#contact').addEventListener('submit', event => {\n  event.preventDefault();\n  const data = new FormData(event.currentTarget);\n  document.querySelector('#message').textContent = 'Olá, ' + data.get('nome') + '!';\n  console.log('Formulário validado.');\n});` },
  counter: { label: 'Contador DOM', html: '<main>\n  <h1 id="value">0</h1>\n  <div>\n    <button data-action="minus">−</button>\n    <button data-action="reset">Resetar</button>\n    <button data-action="plus">+</button>\n  </div>\n</main>', css: 'body { margin: 0; min-height: 100vh; display: grid; place-items: center; font-family: system-ui; text-align: center; }\nh1 { font-size: 72px; margin: 0 0 20px; }\nbutton { padding: 10px 14px; }', js: `let value = 0;\nconst output = document.querySelector('#value');\nfunction render() { output.textContent = value; console.log('Valor:', value); }\ndocument.addEventListener('click', event => {\n  const action = event.target.dataset.action;\n  if (action === 'plus') value++;\n  if (action === 'minus') value--;\n  if (action === 'reset') value = 0;\n  if (action) render();\n});` }
};

const storageKey = 'enterprise-educacional-state-v2';
const legacyStorageKey = 'enterprise-educacional-state-v1';
function loadState() {
  try {
    const current = JSON.parse(localStorage.getItem(storageKey));
    if (current) return current;
    const legacy = JSON.parse(localStorage.getItem(legacyStorageKey));
    return legacy || {};
  } catch {
    return {};
  }
}

let state = Object.assign({
  completedLessons: [],
  completedExercises: [],
  completedChallenges: [],
  completedProjects: [],
  projectSteps: {},
  exerciseAttempts: {},
  lastLesson: lessons[0]?.id || '',
  theme: '',
  playground: null,
  playgroundPreset: 'default',
  activity: []
}, loadState());

function migrateState() {
  state.completedLessons = [...new Set((state.completedLessons || []).filter(id => lessonById.has(id)))];
  state.completedExercises = [...new Set((state.completedExercises || []).filter(id => exercises.some(ex => String(ex.id) === String(id))))];
  const challengeIds = new Set(challenges.map(c => c.id));
  state.completedChallenges = [...new Set((state.completedChallenges || []).map(value => challengeIds.has(value) ? value : challenges.find(c => c.title === value)?.id).filter(Boolean))];
  const projectIds = new Set(projects.map(p => p.id));
  state.completedProjects = [...new Set((state.completedProjects || []).map(value => projectIds.has(value) ? value : projects.find(p => p.title === value)?.id).filter(Boolean))];
  if (!lessonById.has(state.lastLesson)) state.lastLesson = lessons[0]?.id || '';
  state.projectSteps ||= {};
  state.exerciseAttempts ||= {};
  state.activity ||= [];
}
migrateState();

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify(state));
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]));
}
function escapeAttr(value = '') { return escapeHtml(value).replace(/`/g, '&#96;'); }
function normalizeText(value = '') { return String(value).trim().toLocaleLowerCase('pt-BR').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' '); }
function clamp(number, min, max) { return Math.min(Math.max(number, min), max); }
function formatTime(timestamp) {
  if (!timestamp) return 'agora';
  const diff = Date.now() - timestamp;
  if (diff < 60_000) return 'agora';
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} min`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} h`;
  if (diff < 172_800_000) return 'ontem';
  return new Intl.DateTimeFormat('pt-BR', { day:'2-digit', month:'short' }).format(timestamp);
}
function techLabel(courseId) { return courseById.get(courseId)?.title || courseId || 'Conteúdo'; }
function techCode(courseId) { return courseById.get(courseId)?.code || String(courseId || '').toUpperCase(); }
function techIconId(courseId) { return ({ html:'html', css:'css', javascript:'js', python:'python' })[courseId] || 'book'; }
function getCourseLessons(courseId) { return lessonsByCourse.get(courseId) || []; }
function getFirstLesson(courseId) { return getCourseLessons(courseId)[0]; }
function getLessonIndexInCourse(lesson) { return Math.max(0, getCourseLessons(lesson.courseId).findIndex(item => item.id === lesson.id)); }
function getModule(course, moduleId) { return course?.modules?.find(module => module.id === moduleId); }
function getModuleIndex(course, moduleId) { return Math.max(0, course?.modules?.findIndex(module => module.id === moduleId) ?? 0); }
function courseProgress(courseId) {
  const courseLessons = getCourseLessons(courseId);
  if (!courseLessons.length) return 0;
  const completed = courseLessons.filter(lesson => state.completedLessons.includes(lesson.id)).length;
  return Math.round((completed / courseLessons.length) * 100);
}
function overallProgress() {
  const lessonPart = lessons.length ? state.completedLessons.length / lessons.length : 0;
  const exercisePart = exercises.length ? state.completedExercises.length / exercises.length : 0;
  const challengePart = challenges.length ? state.completedChallenges.length / challenges.length : 0;
  const projectPart = projects.length ? state.completedProjects.length / projects.length : 0;
  return Math.round((lessonPart * .5 + exercisePart * .25 + projectPart * .15 + challengePart * .10) * 100);
}
function estimateLessonTime(lesson) {
  const source = [lesson.intro, lesson.explanation, lesson.deepDive, lesson.practicalContext, lesson.analogy, lesson.summary, ...(lesson.understand || []), ...(lesson.errors || [])].filter(Boolean).join(' ');
  const words = source.trim().split(/\s+/).filter(Boolean).length;
  const reading = Math.max(4, Math.ceil(words / 180));
  const practice = lesson.editor ? 7 : 4;
  return { reading, practice, total: reading + practice };
}
function getRecommendedLesson() {
  const last = lessonById.get(state.lastLesson);
  if (last && !state.completedLessons.includes(last.id)) return last;
  if (last) {
    const courseLessons = getCourseLessons(last.courseId);
    const index = courseLessons.findIndex(item => item.id === last.id);
    const nextSameCourse = courseLessons.slice(index + 1).find(item => !state.completedLessons.includes(item.id));
    if (nextSameCourse) return nextSameCourse;
  }
  return lessons.find(lesson => !state.completedLessons.includes(lesson.id)) || lessons[0];
}
function recordActivity(type, label, meta = '') {
  state.activity.unshift({ id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`, type, label, meta, time: Date.now() });
  state.activity = state.activity.slice(0, 40);
  saveState();
}

function updateDocumentMeta(pageName, detail = '') {
  const titles = {
    home: 'Enterprise Educacional', trilhas: 'Trilhas | Enterprise Educacional', aula: detail ? `${detail} | Enterprise Educacional` : 'Aula | Enterprise Educacional',
    exercicios: 'Exercícios | Enterprise Educacional', desafios: 'Desafios | Enterprise Educacional', projetos: 'Projetos | Enterprise Educacional', playground: 'Playground | Enterprise Educacional', glossario: 'Glossário | Enterprise Educacional', progresso: 'Progresso | Enterprise Educacional', 'not-found':'Página não encontrada | Enterprise Educacional'
  };
  document.title = titles[pageName] || titles.home;
}

let currentLessonId = state.lastLesson;
let currentExercise = exercises[0]?.id;
let exerciseFilter = 'Todos';
let selectedTerm = glossary[0]?.term || '';
let letterFilter = 'Todos';

function route() {
  const raw = decodeURIComponent(location.hash.slice(1) || 'home');
  const [root, ...rest] = raw.split('/');
  let pageName = root;
  if (!['home','trilhas','aula','exercicios','desafios','projetos','playground','glossario','progresso'].includes(pageName)) pageName = 'not-found';

  if (pageName === 'aula') {
    const id = rest.join('/') || state.lastLesson || lessons[0]?.id;
    if (lessonById.has(id)) currentLessonId = id;
    else pageName = 'not-found';
  }
  if (pageName === 'exercicios' && rest[0]) {
    const found = exercises.find(ex => String(ex.id) === String(rest[0]));
    if (found) { currentExercise = found.id; exerciseFilter = 'Todos'; }
  }
  if (pageName === 'glossario' && rest.length) {
    const term = rest.join('/');
    const foundTerm = glossary.find(item => normalizeText(item.term) === normalizeText(term));
    if (foundTerm) { selectedTerm = foundTerm.term; letterFilter = 'Todos'; if ($('#glossarySearch')) $('#glossarySearch').value = ''; }
  }

  $$('.page').forEach(page => page.classList.toggle('active', page.dataset.page === pageName));
  $$('.desktop-nav a').forEach(link => {
    const hrefPage = link.getAttribute('href').replace('#','');
    const active = pageName === hrefPage || (pageName === 'aula' && hrefPage === 'trilhas');
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
  });

  if (pageName === 'home') renderHome();
  if (pageName === 'trilhas') renderTracks();
  if (pageName === 'aula') renderLesson(currentLessonId);
  if (pageName === 'exercicios') renderExercises();
  if (pageName === 'desafios') renderChallenges();
  if (pageName === 'projetos') renderProjects();
  if (pageName === 'glossario') renderGlossary();
  if (pageName === 'progresso') renderProgress();
  if (pageName === 'playground') refreshPlaygroundFromState();

  updateDocumentMeta(pageName, pageName === 'aula' ? lessonById.get(currentLessonId)?.title : '');
  if (pageName !== 'not-found') window.scrollTo({ top: 0, behavior: 'instant' });
}
window.addEventListener('hashchange', route);

function renderPlatformStrip() {
  const stats = [
    { icon:'book', text:`${courses.length} trilhas · ${lessons.length.toLocaleString('pt-BR')} aulas` },
    { icon:'exercise', text:`${exercises.length.toLocaleString('pt-BR')} exercícios com feedback` },
    { icon:'project', text:`${projects.length} projetos · ${challenges.length} desafios` },
    { icon:'progress', text:'progresso salvo no navegador' }
  ];
  $('#platformStrip').innerHTML = stats.map(item => `<div class="platform-stat"><span class="platform-stat-icon"><svg class="ui-icon"><use href="#icon-${item.icon}"></use></svg></span><span>${item.text}</span></div>`).join('');
}

function renderHome() {
  renderPlatformStrip();
  $('#homeTechGrid').innerHTML = courses.map(course => {
    const progress = courseProgress(course.id);
    const courseLessons = getCourseLessons(course.id);
    const next = courseLessons.find(lesson => !state.completedLessons.includes(lesson.id)) || courseLessons[0];
    return `<a class="tech-card" href="#aula/${encodeURIComponent(next?.id || '')}">
      <span class="tech-code">${escapeHtml(course.code)}</span>
      <h3>${escapeHtml(course.title)}</h3>
      <p>${escapeHtml(course.description)}</p>
      <div class="card-foot"><span>${course.modules.length} módulos · ${courseLessons.length} aulas</span><span><strong>${progress ? `${progress}% concluído` : 'Começar trilha'}</strong>${next ? escapeHtml(next.title) : ''}</span></div>
    </a>`;
  }).join('');

  const progress = overallProgress();
  const recommended = getRecommendedLesson();
  $('#continuePercent').textContent = `${progress}%`;
  $('#continueBar').style.width = `${progress}%`;
  if (!state.completedLessons.length && !state.completedExercises.length) {
    const htmlStart = getFirstLesson('html') || lessons[0];
    $('#continueEyebrow').textContent = 'Comece sua jornada';
    $('#continueTitle').textContent = 'Nunca programou? Comece pelos fundamentos.';
    $('#continueText').textContent = 'HTML é um ótimo ponto de entrada para entender como a Web é estruturada. Depois, avance para CSS e JavaScript — ou escolha Python para começar pela lógica.';
    $('#continueLabel').textContent = 'Progresso geral';
    $('#continueMeta').innerHTML = '<span>Iniciante</span><span>Sem pré-requisitos</span><span>Aprenda no seu ritmo</span>';
    $('#continueButton').textContent = 'Começar com HTML';
    $('#continueButton').href = htmlStart ? `#aula/${encodeURIComponent(htmlStart.id)}` : '#trilhas';
  } else if (recommended) {
    const course = courseById.get(recommended.courseId);
    const time = estimateLessonTime(recommended);
    $('#continueEyebrow').textContent = 'Seu próximo passo';
    $('#continueTitle').textContent = recommended.title;
    $('#continueText').textContent = `Continue em ${course?.title || 'sua trilha'} · ${recommended.moduleTitle}. Seu progresso foi salvo neste navegador.`;
    $('#continueLabel').textContent = `${course?.title || ''} — ${recommended.moduleTitle}`;
    $('#continueMeta').innerHTML = `<span>${time.reading} min de leitura</span><span>${time.practice} min de prática</span><span>${courseProgress(recommended.courseId)}% da trilha</span>`;
    $('#continueButton').textContent = 'Continuar estudando';
    $('#continueButton').href = `#aula/${encodeURIComponent(recommended.id)}`;
  }
}

function renderTracks() {
  $('#trackGrid').innerHTML = courses.map(course => {
    const courseLessons = getCourseLessons(course.id);
    const progress = courseProgress(course.id);
    const next = courseLessons.find(lesson => !state.completedLessons.includes(lesson.id)) || courseLessons[0];
    const moduleRows = course.modules.slice(0, 5).map((module, index) => {
      const done = module.lessonIds.filter(id => state.completedLessons.includes(id)).length;
      return `<div class="module-row"><span>${String(index + 1).padStart(2,'0')} · ${escapeHtml(module.title)}</span><span>${done}/${module.lessonIds.length}</span></div>`;
    }).join('');
    return `<article class="track-card">
      <div class="track-top"><div><span class="eyebrow simple">${escapeHtml(course.code)}</span><h2>${escapeHtml(course.title)}</h2><p>${escapeHtml(course.description)}</p></div><div class="track-icon">${escapeHtml(course.code)}</div></div>
      <div class="track-meta"><span>${course.modules.length} módulos</span><span>${courseLessons.length} aulas</span><span>${escapeHtml(course.level || 'Iniciante → Intermediário')}</span></div>
      <div class="track-modules">${moduleRows}${course.modules.length > 5 ? `<div class="module-row"><span>+ ${course.modules.length - 5} módulos</span><span>em sequência</span></div>` : ''}</div>
      ${next ? `<div class="track-next"><small>${progress ? 'Próximo conteúdo' : 'Primeira aula'}</small><strong>${escapeHtml(next.moduleTitle)} → ${escapeHtml(next.title)}</strong></div>` : ''}
      <div class="progress-label"><span>Progresso</span><strong>${progress}%</strong></div><div class="progress" style="margin:8px 0 18px"><span style="width:${progress}%"></span></div>
      <a class="button ${progress ? 'secondary' : 'primary'}" href="${next ? `#aula/${encodeURIComponent(next.id)}` : '#trilhas'}">${progress ? 'Continuar trilha' : 'Começar trilha'}</a>
    </article>`;
  }).join('');
}

function glossaryAwareText(text = '', maxTerms = 3) {
  if (!text || !glossary.length) return escapeHtml(text);
  const candidates = glossary.filter(item => normalizeText(text).includes(normalizeText(item.term))).sort((a,b) => b.term.length - a.term.length).slice(0, maxTerms);
  if (!candidates.length) return escapeHtml(text);
  const pattern = new RegExp(`(${candidates.map(item => item.term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'giu');
  const termLookup = new Map(candidates.map(item => [normalizeText(item.term), item.term]));
  return String(text).split(pattern).map(part => {
    const match = termLookup.get(normalizeText(part));
    return match ? `<button type="button" class="term-inline" data-term="${escapeAttr(match)}">${escapeHtml(part)}</button>` : escapeHtml(part);
  }).join('');
}

function renderLesson(id) {
  const lesson = lessonById.get(id) || lessons[0];
  if (!lesson) return;
  currentLessonId = lesson.id;
  state.lastLesson = lesson.id;
  saveState();

  const course = courseById.get(lesson.courseId);
  const courseLessons = getCourseLessons(lesson.courseId);
  const lessonIndex = getLessonIndexInCourse(lesson);
  const module = getModule(course, lesson.moduleId);
  const moduleIndex = getModuleIndex(course, lesson.moduleId);
  const moduleLessonIndex = Math.max(0, module?.lessonIds?.indexOf(lesson.id) ?? 0);
  const done = state.completedLessons.includes(lesson.id);
  const time = estimateLessonTime(lesson);

  $('#lessonCourseCode').textContent = course?.code || techCode(lesson.courseId);
  $('#lessonCourseTitle').textContent = course?.title || techLabel(lesson.courseId);
  $('#lessonModuleLabel').textContent = `${course?.modules?.length || 0} módulos · ${courseLessons.length} aulas`;
  $('#lessonCoursePercent').textContent = `${courseProgress(lesson.courseId)}%`;
  $('#lessonCourseBar').style.width = `${courseProgress(lesson.courseId)}%`;

  $('#lessonNav').innerHTML = (course?.modules || []).map((mod, modIndex) => {
    const modLessons = (mod.lessonIds || []).map(lessonId => lessonById.get(lessonId)).filter(Boolean);
    const modDone = modLessons.filter(item => state.completedLessons.includes(item.id)).length;
    const isCurrent = mod.id === lesson.moduleId;
    return `<details class="lesson-module-group" ${isCurrent ? 'open' : ''}>
      <summary class="lesson-module-title">${String(modIndex + 1).padStart(2,'0')} · ${escapeHtml(mod.title)} <span>${modDone}/${modLessons.length}</span></summary>
      <div>${modLessons.map((item, index) => `<button class="${item.id === lesson.id ? 'active ' : ''}${state.completedLessons.includes(item.id) ? 'done' : ''}" data-lesson="${escapeAttr(item.id)}" ${item.id === lesson.id ? 'aria-current="page"' : ''}><span class="lesson-state">${state.completedLessons.includes(item.id) ? '✓' : index + 1}</span><span>${escapeHtml(item.title)}</span></button>`).join('')}</div>
    </details>`;
  }).join('');

  const sections = [
    ['objetivos','O que você vai aprender', lesson.objectives?.length],
    ['explicacao','Explicação', lesson.explanation],
    ['aprofundamento','Aprofundamento', lesson.deepDive || lesson.practicalContext],
    ['sintaxe','Sintaxe e exemplo', lesson.syntax || lesson.code],
    ['entenda','Entenda o código', lesson.understand?.length],
    ['pratica','Prática', lesson.practice || lesson.editor],
    ['revisao','Revisão', lesson.summary]
  ].filter(([, , show]) => show);

  const relatedTerms = glossary.filter(term => {
    const combined = normalizeText([lesson.title, lesson.explanation, lesson.deepDive, lesson.practicalContext].filter(Boolean).join(' '));
    return combined.includes(normalizeText(term.term));
  }).slice(0, 6);

  const langLabel = lesson.courseId === 'javascript' ? 'JavaScript' : lesson.courseId === 'python' ? 'Python' : lesson.courseId.toUpperCase();
  const code = lesson.code || lesson.syntax || '';
  const codeBlock = code ? `<div class="code-block"><div class="code-head"><span>${escapeHtml(langLabel)}</span><button class="text-button copy-example" type="button"><svg class="ui-icon"><use href="#icon-copy"></use></svg>Copiar</button></div><pre><code>${escapeHtml(code)}</code></pre></div>` : '';
  const editorButton = lesson.editor ? `<a class="button secondary" href="#playground" id="openLessonInPlayground"><svg class="ui-icon"><use href="#icon-terminal"></use></svg>Abrir este exemplo no Playground</a>` : '';
  const prev = courseLessons[lessonIndex - 1];
  const next = courseLessons[lessonIndex + 1];

  $('#lessonContent').innerHTML = `
    <div class="lesson-breadcrumb"><a href="#trilhas">Trilhas</a> / ${escapeHtml(course?.title || '')} / ${escapeHtml(lesson.moduleTitle)} / ${escapeHtml(lesson.title)}</div>
    <div class="lesson-header-meta"><span><svg class="ui-icon"><use href="#icon-book"></use></svg>Módulo ${moduleIndex + 1} de ${course?.modules?.length || 1}</span><span>Aula ${lessonIndex + 1} de ${courseLessons.length}</span><span><svg class="ui-icon"><use href="#icon-clock"></use></svg>~${time.total} min</span></div>
    <h1>${escapeHtml(lesson.title)}</h1>
    <p class="lesson-intro">${glossaryAwareText(lesson.intro, 2)}</p>
    <div class="lesson-top-grid">
      <div>
        ${lesson.objectives?.length ? `<section class="lesson-section lesson-objectives" id="objetivos"><h2>O que você vai aprender</h2><ul>${lesson.objectives.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul></section>` : ''}
        ${lesson.explanation ? `<section class="lesson-section" id="explicacao"><h2>Explicação</h2><p>${glossaryAwareText(lesson.explanation, 3)}</p>${lesson.analogy ? `<div class="callout"><strong>Uma forma de pensar</strong><p>${glossaryAwareText(lesson.analogy, 2)}</p></div>` : ''}</section>` : ''}
        ${(lesson.deepDive || lesson.practicalContext) ? `<section class="lesson-section" id="aprofundamento"><h2>Aprofundamento</h2>${lesson.deepDive ? `<p>${glossaryAwareText(lesson.deepDive, 3)}</p>` : ''}${lesson.practicalContext ? `<div class="callout"><strong>Na prática</strong><p>${glossaryAwareText(lesson.practicalContext, 2)}</p></div>` : ''}</section>` : ''}
        ${(lesson.syntax || code) ? `<section class="lesson-section" id="sintaxe"><h2>Sintaxe e exemplo</h2>${lesson.syntax && lesson.syntax !== code ? `<p>${glossaryAwareText(lesson.syntax, 1)}</p>` : ''}${codeBlock}${lesson.result ? `<div class="callout"><strong>Resultado</strong><p style="white-space:pre-line">${escapeHtml(lesson.result)}</p></div>` : ''}</section>` : ''}
        ${lesson.understand?.length ? `<section class="lesson-section" id="entenda"><h2>Entenda o código</h2><ul>${lesson.understand.map(item => `<li>${glossaryAwareText(item, 1)}</li>`).join('')}</ul></section>` : ''}
        <div class="lesson-rich-grid">${lesson.tip ? `<div class="mini-callout"><strong>Boa prática</strong><p>${glossaryAwareText(lesson.tip, 1)}</p></div>` : ''}${lesson.errors?.length ? `<div class="mini-callout"><strong>Erros comuns</strong><p>${escapeHtml(lesson.errors[0])}</p></div>` : ''}</div>
        ${lesson.errors?.length > 1 ? `<div class="callout warning"><strong>Outros erros para evitar</strong><p>${escapeHtml(lesson.errors.slice(1).join(' • '))}</p></div>` : ''}
        ${(lesson.practice || lesson.editor || lesson.checkpoint) ? `<section class="lesson-section" id="pratica"><h2>Pratique agora</h2>${lesson.practice ? `<p>${glossaryAwareText(lesson.practice, 2)}</p>` : '<p>Experimente o exemplo e altere pequenas partes para observar o comportamento.</p>'}${lesson.checkpoint?.length ? `<div class="callout"><strong>Checkpoint</strong><ul>${lesson.checkpoint.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul></div>` : ''}${editorButton}</section>` : ''}
        ${relatedTerms.length ? `<div class="lesson-concepts"><span class="eyebrow simple" style="width:100%;margin-bottom:4px">Conceitos desta aula</span>${relatedTerms.map(term => `<button class="term-inline" type="button" data-term="${escapeAttr(term.term)}">${escapeHtml(term.term)}</button>`).join('')}</div>` : ''}
        ${lesson.summary ? `<section class="lesson-section" id="revisao"><h2>Resumo</h2><p>${glossaryAwareText(lesson.summary, 2)}</p>${lesson.nextStep ? `<div class="callout tip"><strong>Próximo passo</strong><p>${escapeHtml(lesson.nextStep)}</p></div>` : ''}</section>` : ''}
      </div>
      <nav class="lesson-toc" aria-label="Nesta aula"><strong>Nesta aula</strong>${sections.map(([idSection, label]) => `<a href="#${idSection}" data-scroll-section="${idSection}">${label}</a>`).join('')}</nav>
    </div>
    <div class="lesson-actions"><div>${prev ? `<button class="text-button lesson-prev" data-lesson="${escapeAttr(prev.id)}" type="button">← ${escapeHtml(prev.title)}</button>` : '<a class="text-link" href="#trilhas">← Voltar para Trilhas</a>'}</div><button class="button ${done ? 'secondary' : 'primary'}" id="completeLesson" type="button">${done ? 'Aula concluída ✓' : 'Marcar como concluída'}</button><div class="next">${next ? `<button class="text-button lesson-next" data-lesson="${escapeAttr(next.id)}" type="button">${escapeHtml(next.title)} →</button>` : '<a class="text-link" href="#exercicios">Praticar exercícios →</a>'}</div></div>`;

  $$('#lessonNav button[data-lesson]').forEach(button => button.addEventListener('click', () => navigateToLesson(button.dataset.lesson)));
  $$('.lesson-prev,.lesson-next').forEach(button => button.addEventListener('click', () => navigateToLesson(button.dataset.lesson)));
  $$('.copy-example').forEach(button => button.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(code); button.textContent = 'Copiado'; setTimeout(() => { button.innerHTML = '<svg class="ui-icon"><use href="#icon-copy"></use></svg>Copiar'; }, 1200); } catch { button.textContent = 'Não foi possível copiar'; }
  }));
  $('#completeLesson')?.addEventListener('click', () => toggleLessonCompletion(lesson));
  $('#openLessonInPlayground')?.addEventListener('click', () => {
    state.playground = Object.assign({}, defaultPlayground, lesson.editor || {});
    state.playgroundPreset = 'lesson';
    saveState();
  });
  $$('[data-scroll-section]').forEach(link => link.addEventListener('click', event => {
    event.preventDefault();
    document.getElementById(link.dataset.scrollSection)?.scrollIntoView({ behavior: 'smooth', block:'start' });
  }));
  initTermButtons();

  setTimeout(() => {
    const active = $('#lessonNav button.active');
    active?.scrollIntoView({ block:'center' });
  }, 0);
}

function navigateToLesson(id) {
  location.hash = `#aula/${encodeURIComponent(id)}`;
  if (location.hash === `#aula/${encodeURIComponent(id)}`) renderLesson(id);
}
function toggleLessonCompletion(lesson) {
  const completed = state.completedLessons.includes(lesson.id);
  if (completed) {
    state.completedLessons = state.completedLessons.filter(id => id !== lesson.id);
    recordActivity('lesson', `Reabriu “${lesson.title}”`, techLabel(lesson.courseId));
  } else {
    state.completedLessons.push(lesson.id);
    recordActivity('lesson', `Aula concluída: ${lesson.title}`, `${techLabel(lesson.courseId)} · ${lesson.moduleTitle}`);
  }
  saveState();
  renderLesson(lesson.id);
  renderHome();
}

function renderExerciseFilters() {
  const technologies = ['Todos', ...courses.map(course => course.title)];
  $('#exerciseFilters').innerHTML = technologies.map(filter => `<button class="filter-chip ${filter === exerciseFilter ? 'active' : ''}" data-filter="${escapeAttr(filter)}" type="button">${escapeHtml(filter)}</button>`).join('');
  $$('#exerciseFilters button').forEach(button => button.addEventListener('click', () => {
    exerciseFilter = button.dataset.filter;
    renderExercises();
  }));
}

function acceptedExerciseAnswers(exercise) {
  return [exercise.answer, ...(exercise.answers || [])].filter(answer => answer !== undefined && answer !== null);
}
function isExerciseCorrect(exercise, raw) {
  const normalized = normalizeText(raw);
  if (!normalized) return false;
  return acceptedExerciseAnswers(exercise).some(answer => normalizeText(answer) === normalized);
}
function renderExercises() {
  if (!exercises.length) return;
  renderExerciseFilters();
  const list = exerciseFilter === 'Todos' ? exercises : exercises.filter(exercise => normalizeText(exercise.tech) === normalizeText(exerciseFilter));
  if (!list.some(exercise => String(exercise.id) === String(currentExercise))) currentExercise = list[0]?.id;
  const currentIndex = Math.max(0, list.findIndex(exercise => String(exercise.id) === String(currentExercise)));
  $('#exerciseListMeta').textContent = `${list.length} exercícios · ${list.filter(exercise => state.completedExercises.includes(exercise.id)).length} concluídos`;
  $('#exerciseList').innerHTML = list.map(exercise => `<button class="${String(exercise.id) === String(currentExercise) ? 'active' : ''}" data-id="${escapeAttr(exercise.id)}" type="button"><small>${escapeHtml(exercise.tech)} · ${escapeHtml(exercise.difficulty || exercise.type)}</small><strong>${escapeHtml(exercise.title)}</strong>${state.completedExercises.includes(exercise.id) ? '<span class="exercise-list-state">✓</span>' : ''}</button>`).join('');
  $$('#exerciseList button').forEach(button => button.addEventListener('click', () => { currentExercise = button.dataset.id; renderExercises(); }));

  const exercise = list[currentIndex];
  if (!exercise) { $('#exerciseCard').innerHTML = '<div class="empty-state">Nenhum exercício neste filtro.</div>'; return; }
  currentExercise = exercise.id;
  const complete = state.completedExercises.includes(exercise.id);
  const attempts = state.exerciseAttempts[exercise.id] || 0;
  $('#exerciseCard').innerHTML = `<div class="exercise-card-head"><div><div class="badge-row"><span class="badge">${escapeHtml(exercise.tech)}</span><span class="badge">${escapeHtml(exercise.difficulty || 'Prática')}</span><span class="badge">${escapeHtml(exercise.type)}</span></div><h2>${escapeHtml(exercise.title)}</h2></div><span class="exercise-counter">${currentIndex + 1} de ${list.length}</span></div><p class="exercise-prompt">${escapeHtml(exercise.prompt)}</p>${exercise.options ? `<div class="options">${exercise.options.map(option => `<button class="option" data-value="${escapeAttr(option)}" type="button">${escapeHtml(option)}</button>`).join('')}</div>` : `<textarea class="answer-input" id="exerciseAnswer" placeholder="Digite sua resposta..." aria-label="Sua resposta"></textarea>`}<div class="exercise-actions"><button class="button primary" id="checkAnswer" type="button">Verificar resposta</button><span class="attempt-count">${attempts ? `${attempts} tentativa${attempts === 1 ? '' : 's'}` : 'Nenhuma tentativa ainda'}</span></div>${complete ? '<div class="feedback success"><strong>Exercício concluído</strong><p>Você já acertou este exercício. Pode refazer para revisar o conceito.</p></div>' : ''}<div id="exerciseFeedback" aria-live="polite"></div>`;

  let selected = '';
  $$('.option', $('#exerciseCard')).forEach(option => option.addEventListener('click', () => {
    $$('.option', $('#exerciseCard')).forEach(item => item.classList.remove('selected'));
    option.classList.add('selected');
    selected = option.dataset.value;
  }));
  $('#checkAnswer')?.addEventListener('click', () => {
    const raw = exercise.options ? selected : ($('#exerciseAnswer')?.value || '');
    state.exerciseAttempts[exercise.id] = (state.exerciseAttempts[exercise.id] || 0) + 1;
    const correct = isExerciseCorrect(exercise, raw);
    const conceptLink = exercise.relatedLessonId && lessonById.has(exercise.relatedLessonId) ? `<a class="text-link" href="#aula/${encodeURIComponent(exercise.relatedLessonId)}">Revisar conceito na aula →</a>` : '';
    $('#exerciseFeedback').innerHTML = `<div class="feedback ${correct ? 'success' : 'error'}"><strong>${correct ? 'Correto — conceito entendido' : 'Ainda não — revise o raciocínio'}</strong><p>${correct ? escapeHtml(exercise.explanation) : `Sua resposta não corresponde ao resultado esperado. ${escapeHtml(exercise.explanation)}`}</p><div class="feedback-actions">${conceptLink}${correct && list[currentIndex + 1] ? `<button class="text-button" id="nextExercise" type="button">Próximo exercício →</button>` : '<button class="text-button" id="retryExercise" type="button">Tentar novamente</button>'}</div></div>`;
    if (correct && !state.completedExercises.includes(exercise.id)) {
      state.completedExercises.push(exercise.id);
      recordActivity('exercise', `Exercício concluído: ${exercise.title}`, `${exercise.tech} · ${exercise.difficulty || exercise.type}`);
    }
    saveState();
    $('#nextExercise')?.addEventListener('click', () => { currentExercise = list[currentIndex + 1].id; renderExercises(); });
    $('#retryExercise')?.addEventListener('click', () => { $('#exerciseAnswer')?.focus(); });
    renderHome();
  });
}

function renderChallenges() {
  $('#challengeGrid').innerHTML = challenges.map((challenge, index) => {
    const completed = state.completedChallenges.includes(challenge.id);
    return `<article class="challenge-card"><div class="badge-row"><span class="badge">${escapeHtml(challenge.tech)}</span><span class="badge">${escapeHtml(challenge.level)}</span>${completed ? '<span class="badge">Concluído ✓</span>' : ''}</div><h2>${escapeHtml(challenge.title)}</h2><p>${escapeHtml(challenge.description)}</p>${challenge.requirements?.length ? `<div class="requirement-list">${challenge.requirements.slice(0,4).map(item => `<div class="requirement-item">${escapeHtml(item)}</div>`).join('')}</div>` : ''}<div class="card-bottom"><button class="button secondary hint-button" data-id="${index}" type="button">Mostrar dica 1</button><div class="hint-box" id="hint-${index}" hidden></div><button class="text-button challenge-complete" data-id="${escapeAttr(challenge.id)}" type="button" style="margin-top:16px">${completed ? 'Desafio concluído ✓' : 'Marcar como concluído'}</button></div></article>`;
  }).join('');
  $$('.hint-button').forEach(button => {
    let step = 0;
    button.addEventListener('click', () => {
      const challenge = challenges[Number(button.dataset.id)];
      const box = $(`#hint-${button.dataset.id}`);
      box.hidden = false;
      if (step < (challenge.hints?.length || 0)) {
        box.innerHTML = `<strong>Dica ${step + 1}</strong><p>${escapeHtml(challenge.hints[step])}</p>`;
        step += 1;
        button.textContent = step < challenge.hints.length ? `Mostrar dica ${step + 1}` : 'Mostrar solução oficial';
      } else {
        box.innerHTML = `<strong>Solução oficial</strong><p>${escapeHtml(challenge.solution)}</p>`;
        button.disabled = true;
        button.textContent = 'Solução exibida';
      }
    });
  });
  $$('.challenge-complete').forEach(button => button.addEventListener('click', () => {
    const challenge = challenges.find(item => item.id === button.dataset.id);
    if (!challenge) return;
    const completed = state.completedChallenges.includes(challenge.id);
    state.completedChallenges = completed ? state.completedChallenges.filter(id => id !== challenge.id) : [...state.completedChallenges, challenge.id];
    if (!completed) recordActivity('challenge', `Desafio concluído: ${challenge.title}`, challenge.tech);
    saveState(); renderChallenges(); renderHome();
  }));
}

function getProjectStepState(project) {
  const stored = state.projectSteps[project.id] || [];
  return project.steps.map((_, index) => Boolean(stored[index]));
}
function renderProjects() {
  $('#projectGrid').innerHTML = projects.map(project => {
    const stepState = getProjectStepState(project);
    const doneCount = stepState.filter(Boolean).length;
    const percent = project.steps.length ? Math.round((doneCount / project.steps.length) * 100) : 0;
    const completed = state.completedProjects.includes(project.id) || (project.steps.length > 0 && doneCount === project.steps.length);
    return `<article class="project-card"><div class="badge-row">${(project.tech || []).map(tech => `<span class="badge">${escapeHtml(tech)}</span>`).join('')}<span class="badge">${escapeHtml(project.level)}</span>${completed ? '<span class="badge">Concluído ✓</span>' : ''}</div><h2>${escapeHtml(project.title)}</h2><p>${escapeHtml(project.description)}</p>${project.objective ? `<div class="project-details"><div class="requirement-item"><strong>Objetivo:</strong>&nbsp; ${escapeHtml(project.objective)}</div></div>` : ''}<div class="project-progress-line"><span>${doneCount} de ${project.steps.length} etapas</span><strong>${percent}%</strong></div><div class="progress"><span style="width:${percent}%"></span></div><div class="track-modules">${project.steps.map((step, index) => `<label class="project-step-row"><input type="checkbox" class="project-step" data-project="${escapeAttr(project.id)}" data-step="${index}" ${stepState[index] ? 'checked' : ''}><span>${escapeHtml(step)}</span></label>`).join('')}</div><details class="project-more"><summary>Ver requisitos e extensões</summary><div class="requirement-list">${(project.requirements || []).slice(0,4).map(item => `<div class="requirement-item">${escapeHtml(item)}</div>`).join('')}${(project.completion || []).slice(0,3).map(item => `<div class="requirement-item">Critério: ${escapeHtml(item)}</div>`).join('')}${(project.tips || []).slice(0,2).map(item => `<div class="requirement-item">Dica: ${escapeHtml(item)}</div>`).join('')}${(project.extensions || []).slice(0,2).map(item => `<div class="requirement-item">Extensão: ${escapeHtml(item)}</div>`).join('')}</div></details><div class="card-bottom"><button class="button secondary project-complete" data-project="${escapeAttr(project.id)}" type="button">${completed ? 'Projeto concluído ✓' : 'Marcar projeto concluído'}</button></div></article>`;
  }).join('');

  $$('.project-step').forEach(input => input.addEventListener('change', () => {
    const project = projects.find(item => item.id === input.dataset.project);
    if (!project) return;
    const steps = getProjectStepState(project);
    steps[Number(input.dataset.step)] = input.checked;
    state.projectSteps[project.id] = steps;
    const allDone = steps.length && steps.every(Boolean);
    if (allDone && !state.completedProjects.includes(project.id)) {
      state.completedProjects.push(project.id);
      recordActivity('project', `Projeto concluído: ${project.title}`, (project.tech || []).join(' · '));
    }
    if (!allDone) state.completedProjects = state.completedProjects.filter(id => id !== project.id);
    saveState(); renderProjects(); renderHome();
  }));
  $$('.project-complete').forEach(button => button.addEventListener('click', () => {
    const project = projects.find(item => item.id === button.dataset.project);
    if (!project) return;
    const completed = state.completedProjects.includes(project.id);
    if (completed) {
      state.completedProjects = state.completedProjects.filter(id => id !== project.id);
      state.projectSteps[project.id] = project.steps.map(() => false);
    } else {
      state.completedProjects.push(project.id);
      state.projectSteps[project.id] = project.steps.map(() => true);
      recordActivity('project', `Projeto concluído: ${project.title}`, (project.tech || []).join(' · '));
    }
    saveState(); renderProjects(); renderHome();
  }));
}

let activeLang = 'html';
let pg = { ...defaultPlayground };
function refreshPlaygroundFromState() {
  pg = { ...defaultPlayground, ...(state.playground || {}) };
  if ($('#codeEditor')) { updateEditor(); runPlayground(); }
}
function initPlayground() {
  const presetSelect = $('#playgroundPreset');
  presetSelect.innerHTML = Object.entries(playgroundPresets).map(([id, preset]) => `<option value="${id}">${escapeHtml(preset.label)}</option>`).join('');
  if (state.playgroundPreset && playgroundPresets[state.playgroundPreset]) presetSelect.value = state.playgroundPreset;
  pg = { ...defaultPlayground, ...(state.playground || {}) };
  activeLang = 'html';
  updateEditor();
  runPlayground();

  $$('#editorTabs button').forEach(button => button.addEventListener('click', () => selectEditorTab(button.dataset.lang)));
  $('#editorTabs')?.addEventListener('keydown', event => {
    const tabs = $$('#editorTabs button');
    const index = tabs.findIndex(tab => tab.getAttribute('aria-selected') === 'true');
    if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
      event.preventDefault();
      const next = (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      tabs[next].focus(); selectEditorTab(tabs[next].dataset.lang);
    }
  });
  $('#codeEditor').addEventListener('input', () => { pg[activeLang] = $('#codeEditor').value; state.playground = { ...pg }; saveState(); });
  $('#codeEditor').addEventListener('keydown', event => {
    if (event.key === 'Tab') {
      event.preventDefault();
      const textarea = event.currentTarget;
      const start = textarea.selectionStart; const end = textarea.selectionEnd;
      textarea.value = textarea.value.slice(0,start) + '  ' + textarea.value.slice(end);
      textarea.selectionStart = textarea.selectionEnd = start + 2;
      textarea.dispatchEvent(new Event('input'));
    }
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); runPlayground(); }
  });
  $('#runPlayground').addEventListener('click', runPlayground);
  $('#resetPlayground').addEventListener('click', () => {
    const selectedPreset = playgroundPresets[presetSelect.value] || playgroundPresets.default;
    pg = { html:selectedPreset.html, css:selectedPreset.css, js:selectedPreset.js };
    state.playground = { ...pg }; state.playgroundPreset = presetSelect.value; saveState(); updateEditor(); runPlayground();
  });
  $('#copyCode').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText($('#codeEditor').value); $('#copyCode').textContent = 'Copiado'; setTimeout(() => { $('#copyCode').innerHTML = '<svg class="ui-icon"><use href="#icon-copy"></use></svg>Copiar'; }, 1200); } catch { $('#copyCode').textContent = 'Falha ao copiar'; }
  });
  $('#clearConsole').addEventListener('click', clearConsole);
  $('#fullscreenPlayground').addEventListener('click', async () => {
    try {
      if (!document.fullscreenElement) await $('#workbench').requestFullscreen(); else await document.exitFullscreen();
    } catch {}
  });
  presetSelect.addEventListener('change', () => {
    const preset = playgroundPresets[presetSelect.value];
    if (!preset) return;
    const shouldReplace = confirm(`Carregar o preset “${preset.label}”? O código atual do Playground será substituído.`);
    if (!shouldReplace) { presetSelect.value = state.playgroundPreset || 'default'; return; }
    pg = { html:preset.html, css:preset.css, js:preset.js };
    state.playground = { ...pg }; state.playgroundPreset = presetSelect.value; saveState(); updateEditor(); runPlayground();
  });
  initWorkbenchResizer();
  window.addEventListener('message', handlePlaygroundMessage);
}
function selectEditorTab(lang) {
  pg[activeLang] = $('#codeEditor').value;
  activeLang = lang;
  $$('#editorTabs button').forEach(tab => tab.setAttribute('aria-selected', String(tab.dataset.lang === lang)));
  updateEditor();
}
function updateEditor() { $('#codeEditor').value = pg[activeLang] || ''; }
function clearConsole() { $('#playgroundConsole').innerHTML = '<div class="console-empty">Console limpo. Execute o código para gerar novas mensagens.</div>'; }
function appendConsole(level, text) {
  const consoleEl = $('#playgroundConsole');
  if ($('.console-empty', consoleEl)) consoleEl.innerHTML = '';
  const line = document.createElement('div'); line.className = `console-line ${level}`; line.textContent = text; consoleEl.appendChild(line); consoleEl.scrollTop = consoleEl.scrollHeight;
}
function handlePlaygroundMessage(event) {
  const frame = $('#previewFrame');
  if (!frame || event.source !== frame.contentWindow || event.data?.source !== 'ee-playground') return;
  appendConsole(event.data.level || 'log', event.data.text || '');
}
function runPlayground() {
  if (!$('#previewFrame')) return;
  pg[activeLang] = $('#codeEditor')?.value ?? pg[activeLang];
  clearConsole();
  const bootstrap = `<script>(function(){const format=v=>{try{return typeof v==='string'?v:JSON.stringify(v)}catch{return String(v)}};['log','warn','error'].forEach(level=>{const original=console[level].bind(console);console[level]=(...args)=>{parent.postMessage({source:'ee-playground',level,text:args.map(format).join(' ')},'*');original(...args)}});window.onerror=(message,source,line,column)=>{parent.postMessage({source:'ee-playground',level:'error',text:String(message)+' · linha '+line+':'+column},'*')};window.onunhandledrejection=e=>parent.postMessage({source:'ee-playground',level:'error',text:'Promise rejeitada: '+format(e.reason)},'*');})();<\/script>`;
  const doc = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${pg.css}</style></head><body>${bootstrap}${pg.html}<script>${pg.js}<\/script></body></html>`;
  $('#previewFrame').srcdoc = doc;
  $('#runStatus').textContent = 'Executado agora';
  setTimeout(() => { if ($('#runStatus')) $('#runStatus').textContent = 'Pronto'; }, 1600);
  state.playground = { ...pg }; saveState();
}
function initWorkbenchResizer() {
  const resizer = $('#workbenchResizer'); const workbench = $('#workbench');
  if (!resizer || !workbench) return;
  let dragging = false;
  const setSplit = clientX => {
    const rect = workbench.getBoundingClientRect();
    const percent = clamp(((clientX - rect.left) / rect.width) * 100, 36, 70);
    workbench.style.setProperty('--split', `${percent}%`);
  };
  resizer.addEventListener('pointerdown', event => { dragging = true; resizer.setPointerCapture(event.pointerId); });
  resizer.addEventListener('pointermove', event => { if (dragging) setSplit(event.clientX); });
  resizer.addEventListener('pointerup', () => { dragging = false; });
  resizer.addEventListener('keydown', event => {
    if (!['ArrowLeft','ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const current = parseFloat(getComputedStyle(workbench).getPropertyValue('--split')) || 55;
    workbench.style.setProperty('--split', `${clamp(current + (event.key === 'ArrowRight' ? 3 : -3), 36, 70)}%`);
  });
}

function renderGlossary() {
  const letters = ['Todos', ...new Set(glossary.map(item => item.term[0].toUpperCase()))];
  $('#alphabet').innerHTML = letters.map(letter => `<button class="${letterFilter === letter ? 'active' : ''}" data-letter="${escapeAttr(letter)}" aria-label="${letter === 'Todos' ? 'Todos os termos' : `Termos com ${letter}`}" type="button">${letter === 'Todos' ? '•' : escapeHtml(letter)}</button>`).join('');
  $$('#alphabet button').forEach(button => button.addEventListener('click', () => { letterFilter = button.dataset.letter; renderGlossary(); }));
  const query = normalizeText($('#glossarySearch').value || '');
  const filtered = glossary.filter(item => (letterFilter === 'Todos' || item.term[0].toUpperCase() === letterFilter) && (!query || normalizeText(`${item.term} ${item.definition} ${item.detail}`).includes(query)));
  if (!filtered.some(item => item.term === selectedTerm)) selectedTerm = filtered[0]?.term || '';
  $('#glossaryList').innerHTML = filtered.length ? filtered.map(item => `<button class="${item.term === selectedTerm ? 'active' : ''}" data-term="${escapeAttr(item.term)}" type="button">${escapeHtml(item.term)}</button>`).join('') : '<div class="empty-state">Nenhum termo encontrado. Tente outra palavra ou explore uma letra diferente.</div>';
  $$('#glossaryList button').forEach(button => button.addEventListener('click', () => { selectedTerm = button.dataset.term; renderGlossary(); }));
  const term = glossary.find(item => item.term === selectedTerm);
  if (!term) { $('#glossaryDetail').innerHTML = '<div class="empty-state">Selecione um termo para ver a definição.</div>'; return; }
  const relatedLessons = (term.relatedLessonIds || []).map(id => lessonById.get(id)).filter(Boolean).slice(0,6);
  const relatedTerms = glossary.filter(item => item.term !== term.term && normalizeText(item.detail).split(' ').some(word => word.length > 5 && normalizeText(term.detail).includes(word))).slice(0,5);
  $('#glossaryDetail').innerHTML = `<span class="term-type">${escapeHtml(term.category)}</span><h2>${escapeHtml(term.term)}</h2><p class="definition">${escapeHtml(term.definition)}</p><section><h3>Entenda melhor</h3><p>${escapeHtml(term.detail)}</p></section>${relatedLessons.length ? `<section><h3>Aulas relacionadas</h3><div class="related-links">${relatedLessons.map(lesson => `<a class="related-link" href="#aula/${encodeURIComponent(lesson.id)}">${escapeHtml(techLabel(lesson.courseId))} · ${escapeHtml(lesson.title)}</a>`).join('')}</div></section>` : ''}${relatedTerms.length ? `<section><h3>Termos relacionados</h3><div class="related-links">${relatedTerms.map(item => `<button class="related-link" type="button" data-related-term="${escapeAttr(item.term)}">${escapeHtml(item.term)}</button>`).join('')}</div></section>` : ''}`;
  $$('[data-related-term]').forEach(button => button.addEventListener('click', () => { selectedTerm = button.dataset.relatedTerm; renderGlossary(); window.scrollTo({ top:0, behavior:'smooth' }); }));
}

function initTermButtons() {
  $$('.term-inline').forEach(button => button.addEventListener('click', event => showTermPopover(button.dataset.term, event.currentTarget)));
}
function showTermPopover(termName, anchor) {
  const term = glossary.find(item => normalizeText(item.term) === normalizeText(termName));
  if (!term) return;
  const popover = $('#termPopover');
  $('#termPopoverCategory').textContent = term.category;
  $('#termPopoverTitle').textContent = term.term;
  $('#termPopoverDefinition').textContent = term.definition;
  $('#termPopoverOpen').onclick = () => { selectedTerm = term.term; popover.hidden = true; location.hash = `#glossario/${encodeURIComponent(term.term)}`; };
  popover.hidden = false;
  const rect = anchor.getBoundingClientRect();
  const width = Math.min(360, window.innerWidth - 28);
  const left = clamp(rect.left, 14, window.innerWidth - width - 14);
  const top = clamp(rect.bottom + 10, 14, window.innerHeight - 220);
  popover.style.left = `${left}px`; popover.style.top = `${top}px`;
}

function achievements() {
  const firstCourse = courses.find(course => courseProgress(course.id) >= 100);
  return [
    { title:'Primeiro passo', description:'Conclua sua primeira aula.', unlocked:state.completedLessons.length >= 1 },
    { title:'Praticando', description:'Conclua 10 exercícios.', unlocked:state.completedExercises.length >= 10 },
    { title:'Persistente', description:'Conclua 7 aulas.', unlocked:state.completedLessons.length >= 7 },
    { title:firstCourse ? `${firstCourse.title} concluído` : 'Trilha completa', description:'Conclua uma trilha inteira.', unlocked:Boolean(firstCourse) }
  ];
}
function renderProgress() {
  const total = overallProgress();
  $('#progressSummary').innerHTML = `<div class="summary-card primary"><span class="label">Progresso geral</span><strong>${total}%</strong><div class="progress"><span style="width:${total}%"></span></div></div><div class="summary-card"><span class="label">Aulas</span><strong>${state.completedLessons.length}</strong><span class="text-muted">de ${lessons.length}</span></div><div class="summary-card"><span class="label">Exercícios</span><strong>${state.completedExercises.length}</strong><span class="text-muted">de ${exercises.length}</span></div><div class="summary-card"><span class="label">Projetos + desafios</span><strong>${state.completedProjects.length + state.completedChallenges.length}</strong><span class="text-muted">de ${projects.length + challenges.length}</span></div>`;

  const recommended = getRecommendedLesson();
  const activity = state.activity.slice(0,6);
  const courseCards = courses.map(course => {
    const courseLessons = getCourseLessons(course.id);
    const completed = courseLessons.filter(lesson => state.completedLessons.includes(lesson.id)).length;
    const progress = courseProgress(course.id);
    const next = courseLessons.find(lesson => !state.completedLessons.includes(lesson.id));
    return `<article class="progress-card"><div class="progress-card-head"><h2>${escapeHtml(course.title)}</h2><strong>${progress}%</strong></div><div class="progress"><span style="width:${progress}%"></span></div><div class="recent-list"><div class="recent-item"><span>Aulas concluídas</span><span>${completed}/${courseLessons.length}</span></div><div class="recent-item"><span>Módulos</span><span>${course.modules.length}</span></div>${next ? `<div class="recent-item"><span>Próxima aula</span><span>${escapeHtml(next.title)}</span></div>` : '<div class="recent-item"><span>Status</span><span>Trilha concluída</span></div>'}</div>${next ? `<a class="text-link" href="#aula/${encodeURIComponent(next.id)}">Continuar ${escapeHtml(course.title)} →</a>` : ''}</article>`;
  }).join('');
  $('#progressGrid').innerHTML = `${courseCards}<article class="progress-card"><div class="progress-card-head"><h2>Atividade recente</h2></div><div class="recent-list">${activity.length ? activity.map(item => `<div class="recent-item"><span>${escapeHtml(item.label)}</span><span>${escapeHtml(item.meta || formatTime(item.time))} · ${formatTime(item.time)}</span></div>`).join('') : '<div class="empty-state">Conclua uma aula, exercício, desafio ou projeto para iniciar seu histórico.</div>'}</div></article><article class="progress-card"><div class="progress-card-head"><h2>Próximo passo</h2></div>${recommended ? `<p class="text-muted">Continue em <strong>${escapeHtml(recommended.title)}</strong>, no módulo ${escapeHtml(recommended.moduleTitle)} de ${escapeHtml(techLabel(recommended.courseId))}.</p><div class="project-progress-line"><span>${courseProgress(recommended.courseId)}% da trilha</span><span>~${estimateLessonTime(recommended).total} min</span></div><a class="button secondary" href="#aula/${encodeURIComponent(recommended.id)}">Continuar estudando</a>` : '<p class="text-muted">Você concluiu todas as aulas disponíveis. Explore projetos e desafios.</p><a class="button secondary" href="#projetos">Explorar projetos</a>'}</article>`;
  $('#achievementGrid').innerHTML = achievements().map(item => `<article class="achievement-card ${item.unlocked ? '' : 'locked'}"><div class="achievement-icon"><svg class="ui-icon"><use href="#icon-trophy"></use></svg></div><h3>${escapeHtml(item.title)}</h3><p>${item.unlocked ? 'Conquista desbloqueada.' : escapeHtml(item.description)}</p></article>`).join('');
}

let searchActiveIndex = -1;
let currentSearchResults = [];
function buildSearchIndex() {
  const items = [];
  courses.forEach(course => {
    items.push({ type:'Trilha', title:course.title, desc:`${course.modules.length} módulos · ${getCourseLessons(course.id).length} aulas`, href:'#trilhas', keywords:course.description });
    (course.modules || []).forEach(module => {
      const first = lessonById.get(module.lessonIds?.[0]);
      if (first) items.push({ type:'Módulo', title:module.title, desc:`${course.title} · ${module.lessonIds.length} aulas`, href:`#aula/${encodeURIComponent(first.id)}`, keywords:course.title });
    });
  });
  lessons.forEach(lesson => items.push({ type:'Aula', title:lesson.title, desc:`${techLabel(lesson.courseId)} → ${lesson.moduleTitle}`, href:`#aula/${encodeURIComponent(lesson.id)}`, keywords:[lesson.intro,lesson.explanation,lesson.summary].filter(Boolean).join(' ') }));
  exercises.forEach(exercise => items.push({ type:'Exercício', title:exercise.title, desc:`${exercise.tech} · ${exercise.difficulty || exercise.type}`, href:`#exercicios/${encodeURIComponent(exercise.id)}`, keywords:exercise.prompt }));
  challenges.forEach(challenge => items.push({ type:'Desafio', title:challenge.title, desc:`${challenge.tech} · ${challenge.level}`, href:'#desafios', keywords:challenge.description }));
  projects.forEach(project => items.push({ type:'Projeto', title:project.title, desc:(project.tech || []).join(' · '), href:'#projetos', keywords:[project.description, project.objective, ...(project.concepts || [])].join(' ') }));
  glossary.forEach(term => items.push({ type:'Glossário', title:term.term, desc:term.definition, href:`#glossario/${encodeURIComponent(term.term)}`, keywords:term.detail }));
  return items;
}
const searchIndex = buildSearchIndex();
function highlightMatch(text, query) {
  if (!query) return escapeHtml(text);
  const source = String(text);
  const index = normalizeText(source).indexOf(normalizeText(query));
  if (index < 0) return escapeHtml(source);
  const rawQuery = String(query).trim();
  const regex = new RegExp(`(${rawQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'ig');
  return escapeHtml(source).replace(regex, '<mark>$1</mark>');
}
function openSearch() {
  const dialog = $('#searchDialog');
  if (!dialog.open) dialog.showModal();
  setTimeout(() => $('#globalSearch').focus(), 10);
  renderSearch($('#globalSearch').value || '');
}
function renderSearch(query) {
  const normalized = normalizeText(query);
  const ranked = searchIndex.map(item => {
    const title = normalizeText(item.title); const desc = normalizeText(item.desc); const keywords = normalizeText(item.keywords);
    let score = 0;
    if (!normalized) score = 1;
    else if (title === normalized) score = 100;
    else if (title.startsWith(normalized)) score = 80;
    else if (title.includes(normalized)) score = 60;
    else if (desc.includes(normalized)) score = 35;
    else if (keywords.includes(normalized)) score = 15;
    return { item, score };
  }).filter(entry => entry.score > 0).sort((a,b) => b.score - a.score).slice(0,12).map(entry => entry.item);
  currentSearchResults = ranked; searchActiveIndex = ranked.length ? 0 : -1;
  $('#searchResults').innerHTML = ranked.length ? ranked.map((item, index) => `<a class="search-result ${index === searchActiveIndex ? 'active' : ''}" href="${item.href}" data-search-index="${index}"><small>${escapeHtml(item.type)} · ${escapeHtml(item.desc)}</small><strong>${highlightMatch(item.title, query)}</strong></a>`).join('') : `<div class="empty-state"><strong>Não encontramos “${escapeHtml(query)}”.</strong><br>Tente um termo mais geral, verifique a digitação ou explore as Trilhas.</div>`;
  $$('[data-search-index]').forEach(link => link.addEventListener('click', () => $('#searchDialog').close()));
}
function setSearchActive(index) {
  if (!currentSearchResults.length) return;
  searchActiveIndex = (index + currentSearchResults.length) % currentSearchResults.length;
  $$('.search-result').forEach((item, i) => item.classList.toggle('active', i === searchActiveIndex));
  $$('.search-result')[searchActiveIndex]?.scrollIntoView({ block:'nearest' });
}
function initSearch() {
  const dialog = $('#searchDialog'); const input = $('#globalSearch');
  $('#openSearch').addEventListener('click', openSearch);
  input.addEventListener('input', () => renderSearch(input.value));
  input.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown') { event.preventDefault(); setSearchActive(searchActiveIndex + 1); }
    if (event.key === 'ArrowUp') { event.preventDefault(); setSearchActive(searchActiveIndex - 1); }
    if (event.key === 'Enter' && searchActiveIndex >= 0) { event.preventDefault(); const target = $$('.search-result')[searchActiveIndex]; target?.click(); }
  });
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  document.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); openSearch(); }
  });
}

function resolveTheme() {
  if (state.theme === 'dark' || state.theme === 'light') return state.theme;
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
}
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  $('#themeIcon use')?.setAttribute('href', theme === 'dark' ? '#icon-sun' : '#icon-moon');
  $('#themeToggle')?.setAttribute('aria-label', theme === 'dark' ? 'Ativar tema claro' : 'Ativar tema escuro');
  const meta = $('meta[name="theme-color"]'); if (meta) meta.content = theme === 'dark' ? '#08090a' : '#f4f4f1';
}
function initTheme() {
  applyTheme(resolveTheme());
  $('#themeToggle').addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    state.theme = next; applyTheme(next); saveState();
  });
}
function initMobileMenu() {
  const button = $('#mobileMenuButton'); const nav = $('#mobileNav');
  button.addEventListener('click', () => {
    const open = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', String(!open)); nav.hidden = open;
    button.innerHTML = `<svg class="ui-icon" aria-hidden="true"><use href="#icon-${open ? 'menu' : 'close'}"></use></svg>`;
  });
  $$('#mobileNav a').forEach(link => link.addEventListener('click', () => { nav.hidden = true; button.setAttribute('aria-expanded','false'); button.innerHTML = '<svg class="ui-icon" aria-hidden="true"><use href="#icon-menu"></use></svg>'; }));
}
function initLessonMobile() {
  const button = $('#lessonMobileToggle'); const sidebar = $('.lesson-sidebar');
  button.addEventListener('click', () => {
    const open = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', String(!open)); sidebar.classList.toggle('mobile-open', !open);
  });
}
function initGlossary() { $('#glossarySearch').addEventListener('input', renderGlossary); }
function initTermPopover() {
  $('#closeTermPopover').addEventListener('click', () => { $('#termPopover').hidden = true; });
  document.addEventListener('click', event => {
    const popover = $('#termPopover');
    if (!popover.hidden && !popover.contains(event.target) && !event.target.closest('.term-inline')) popover.hidden = true;
  });
}
function initResetProgress() {
  $('#resetProgress').addEventListener('click', () => {
    if (!confirm('Redefinir todo o progresso salvo neste navegador? A ação apagará aulas, exercícios, projetos e desafios concluídos.')) return;
    state.completedLessons = []; state.completedExercises = []; state.completedChallenges = []; state.completedProjects = []; state.projectSteps = {}; state.exerciseAttempts = {}; state.activity = [];
    saveState(); renderProgress(); renderHome(); renderTracks(); renderExercises(); renderProjects(); renderChallenges();
  });
}

function init() {
  initTheme();
  initMobileMenu();
  initLessonMobile();
  initSearch();
  initGlossary();
  initTermPopover();
  initPlayground();
  initResetProgress();
  renderHome(); renderTracks(); renderExercises(); renderChallenges(); renderProjects(); renderGlossary(); renderProgress();
  route();
}
init();
