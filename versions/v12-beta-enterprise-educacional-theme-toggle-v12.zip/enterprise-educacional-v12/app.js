const $ = (s, scope = document) => scope.querySelector(s);
const $$ = (s, scope = document) => [...scope.querySelectorAll(s)];

const courses = [
  { id:'html', code:'HTML', title:'HTML', description:'Estruture páginas com semântica, acessibilidade e conteúdo bem organizado.', modules:['Fundamentos','Conteúdo e mídia','Formulários','Semântica'], lessons:18 },
  { id:'css', code:'CSS', title:'CSS', description:'Crie layouts modernos, responsivos e visualmente consistentes.', modules:['Fundamentos','Box Model','Flexbox e Grid','Responsividade'], lessons:22 },
  { id:'javascript', code:'JS', title:'JavaScript', description:'Aprenda lógica, DOM, eventos, assincronismo e APIs construindo interações reais.', modules:['Fundamentos','Estruturas','DOM e Eventos','Assincronismo'], lessons:28 },
  { id:'python', code:'PY', title:'Python', description:'Domine lógica, estruturas de dados, arquivos, POO, APIs e automação.', modules:['Fundamentos','Coleções','Funções e arquivos','POO e automação'], lessons:26 }
];

const lessons = [
  { id:'introducao', title:'Introdução ao JavaScript', intro:'Entenda onde o JavaScript entra em uma página e por que ele é uma das linguagens mais importantes da web.', objectives:['Entender o papel do JavaScript','Executar sua primeira instrução','Diferenciar HTML, CSS e JavaScript'], explanation:'HTML define a estrutura, CSS cuida da aparência e JavaScript adiciona comportamento. Com ele você pode reagir a cliques, alterar conteúdos, validar formulários e conversar com APIs.', code:'console.log("Olá, JavaScript!");', result:'Olá, JavaScript!', tip:'Comece com exemplos pequenos. Faça uma alteração por vez e observe o resultado.', error:'Esquecer aspas em textos é um erro comum: console.log(Olá) tenta encontrar uma variável chamada Olá.' },
  { id:'variaveis', title:'Variáveis: let e const', intro:'Aprenda a guardar valores para reutilizá-los e alterá-los ao longo do programa.', objectives:['Criar variáveis com let e const','Escolher nomes claros','Entender reatribuição'], explanation:'Variáveis dão nomes a valores. Use const como padrão quando a referência não precisa ser reatribuída e let quando o valor realmente precisa mudar.', code:'const nome = "Ana";\nlet pontos = 10;\n\npontos = pontos + 5;\nconsole.log(nome, pontos);', result:'Ana 15', tip:'Prefira nomes que expliquem a intenção: totalCarrinho é melhor que x.', error:'Tentar fazer const idade = 18; idade = 19; gera erro porque const não permite reatribuição.' },
  { id:'tipos', title:'Tipos de dados', intro:'Conheça strings, números, booleanos e outros valores que formam programas JavaScript.', objectives:['Reconhecer tipos básicos','Usar typeof','Escolher o tipo adequado'], explanation:'O tipo de um valor influencia quais operações fazem sentido. Texto é string, números são number e verdadeiro/falso são boolean.', code:'const curso = "JavaScript";\nconst aulas = 28;\nconst concluido = false;\n\nconsole.log(typeof curso);\nconsole.log(typeof aulas);\nconsole.log(typeof concluido);', result:'string\nnumber\nboolean', tip:'Não confunda "10" com 10. O primeiro é texto; o segundo é número.', error:'Somar "10" + 5 resulta em "105" porque uma das partes é string.' },
  { id:'condicionais', title:'Condicionais', intro:'Faça o programa tomar decisões usando if, else e comparações.', objectives:['Criar condições','Combinar comparações','Entender caminhos alternativos'], explanation:'Uma condicional executa um bloco apenas quando uma expressão é verdadeira. Isso permite criar regras e comportamentos diferentes.', code:'const nota = 8;\n\nif (nota >= 7) {\n  console.log("Aprovado");\n} else {\n  console.log("Continue estudando");\n}', result:'Aprovado', tip:'Mantenha condições fáceis de ler. Extraia regras complexas para variáveis com nomes claros.', error:'Usar = no lugar de === em uma comparação muda o valor em vez de comparar.' }
];

const exercises = [
  { id:1, tech:'JavaScript', type:'Múltipla escolha', title:'Qual declaração usar?', prompt:'Qual opção é a melhor escolha para uma variável que não será reatribuída?', options:['var','let','const','static'], answer:'const', explanation:'const comunica que aquela referência não será reatribuída e deve ser a escolha padrão quando o valor não precisa mudar.' },
  { id:2, tech:'JavaScript', type:'Prever resultado', title:'Qual será a saída?', prompt:'Qual é o resultado de: const n = 4; console.log(n * 3);', answer:'12', explanation:'O operador * multiplica 4 por 3, resultando em 12.' },
  { id:3, tech:'HTML', type:'Completar código', title:'Crie um título principal', prompt:'Digite apenas a tag HTML completa que representa o título principal da página com o texto “Olá”.', answer:'<h1>Olá</h1>', normalize:true, explanation:'h1 representa o título principal da página e deve ser usado com hierarquia semântica.' },
  { id:4, tech:'CSS', type:'Múltipla escolha', title:'Centralização com Flexbox', prompt:'Qual propriedade alinha itens no eixo principal de um container flex?', options:['align-items','justify-content','text-align','place-self'], answer:'justify-content', explanation:'justify-content distribui os itens ao longo do eixo principal do flex container.' },
  { id:5, tech:'Python', type:'Prever resultado', title:'Saída em Python', prompt:'Qual é a saída de: print(2 ** 3)?', answer:'8', explanation:'Em Python, ** representa exponenciação. 2³ é igual a 8.' }
];

const challenges = [
  { title:'Contador interativo', tech:'JavaScript', level:'Iniciante', description:'Crie um contador com botões para aumentar, diminuir e zerar o valor.', hints:['Comece guardando o valor atual em uma variável.','Escute cliques com addEventListener.','Atualize o texto do contador sempre que o valor mudar.'], solution:'Use uma variável contador, três listeners de clique e uma função render() que atualize textContent.' },
  { title:'Card responsivo', tech:'HTML + CSS', level:'Fácil', description:'Construa um card de perfil que se adapte bem do desktop ao celular.', hints:['Use uma largura máxima em vez de largura fixa.','Organize conteúdo com flex ou grid.','Adicione um breakpoint para telas pequenas.'], solution:'Use max-width, padding fluido e media query para reorganizar avatar e conteúdo.' },
  { title:'Analisador de notas', tech:'Python', level:'Médio', description:'Receba várias notas, calcule média e informe maior, menor e situação final.', hints:['Guarde as notas em uma lista.','Use sum, min e max.','Crie uma regra para aprovado, recuperação e reprovado.'], solution:'Leia as notas, calcule media = sum(notas)/len(notas) e derive os demais valores com min/max.' }
];

const projects = [
  { title:'Portfólio pessoal', tech:['HTML','CSS'], level:'Iniciante', description:'Crie uma página profissional apresentando você, seus projetos e formas de contato.', steps:['Estrutura semântica','Hero e apresentação','Grade de projetos','Responsividade'], progress:0 },
  { title:'Lista de tarefas', tech:['HTML','CSS','JavaScript'], level:'Intermediário', description:'Construa uma lista de tarefas com criação, conclusão, remoção e persistência local.', steps:['Interface','Adicionar tarefas','Estados e filtros','localStorage'], progress:0 },
  { title:'Quiz interativo', tech:['JavaScript'], level:'Intermediário', description:'Crie perguntas, pontuação, feedback e tela de resultado final.', steps:['Modelo de perguntas','Renderização','Validação','Resumo final'], progress:0 },
  { title:'Organizador de arquivos', tech:['Python'], level:'Intermediário', description:'Automatize a organização de arquivos em pastas conforme extensão.', steps:['Leitura de diretório','Classificação','Movimentação','Tratamento de erros'], progress:0 },
  { title:'Consumidor de API', tech:['JavaScript','API'], level:'Intermediário', description:'Busque dados de uma API pública e apresente estados de carregamento e erro.', steps:['Fetch','Loading','Renderização','Erros'], progress:0 },
  { title:'Agenda em Python', tech:['Python'], level:'Intermediário', description:'Crie um pequeno sistema de contatos com adicionar, listar, buscar e remover.', steps:['Estrutura de dados','Menu','CRUD','Persistência em arquivo'], progress:0 }
];

const glossary = [
  { term:'Algoritmo', category:'Fundamentos', definition:'Uma sequência de passos para resolver um problema.', detail:'Um algoritmo descreve uma solução de maneira ordenada. Ele pode existir antes mesmo do código e ajuda a organizar o raciocínio.' },
  { term:'API', category:'Web', definition:'Uma forma padronizada para sistemas trocarem informações.', detail:'APIs permitem que uma aplicação solicite dados ou ações de outra aplicação sem precisar conhecer sua implementação interna.' },
  { term:'Array', category:'JavaScript', definition:'Uma estrutura que armazena vários valores em uma lista ordenada.', detail:'Arrays são úteis para coleções como nomes, produtos ou pontuações. Em JavaScript, seus índices começam em zero.' },
  { term:'DOM', category:'JavaScript', definition:'A representação da página HTML como uma árvore de objetos.', detail:'O DOM permite que JavaScript encontre, leia e modifique elementos da página enquanto ela está aberta.' },
  { term:'Função', category:'Fundamentos', definition:'Um bloco reutilizável de código que executa uma tarefa.', detail:'Funções ajudam a evitar repetição, organizar programas e receber dados por parâmetros para produzir resultados.' },
  { term:'JSON', category:'Web', definition:'Um formato de texto usado para representar dados estruturados.', detail:'JSON é muito comum em APIs porque é simples de ler e fácil de converter em objetos em várias linguagens.' },
  { term:'Loop', category:'Fundamentos', definition:'Uma estrutura que repete um bloco de código.', detail:'Loops são usados quando uma tarefa precisa ser repetida várias vezes, como percorrer uma lista de produtos.' },
  { term:'Objeto', category:'JavaScript', definition:'Uma estrutura que agrupa dados relacionados em propriedades.', detail:'Objetos permitem representar entidades como usuário, produto ou curso reunindo valores relacionados sob uma mesma estrutura.' },
  { term:'Parâmetro', category:'Fundamentos', definition:'Um nome usado por uma função para receber um valor.', detail:'Parâmetros tornam funções flexíveis. Na chamada, os valores enviados são chamados de argumentos.' },
  { term:'Variável', category:'Fundamentos', definition:'Um nome associado a um valor que o programa precisa utilizar.', detail:'Variáveis ajudam a guardar e reutilizar informações, como nome do usuário, total de pontos ou estado de uma interface.' }
].sort((a,b)=>a.term.localeCompare(b.term,'pt-BR'));

const defaultPlayground = {
  html:`<main class="card">\n  <span class="tag">Enterprise Educacional</span>\n  <h1>Seu código, seu resultado.</h1>\n  <p>Edite este exemplo e clique em Executar.</p>\n  <button id="action">Testar JavaScript</button>\n</main>`,
  css:`body {\n  margin: 0;\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  font-family: system-ui, sans-serif;\n  background: #f4f4f4;\n  color: #151515;\n}\n.card {\n  width: min(520px, 86vw);\n  padding: 32px;\n  border: 1px solid #d7d7d7;\n  border-radius: 18px;\n  background: white;\n}\n.tag { font-size: 12px; color: #666; }\nbutton { padding: 10px 14px; cursor: pointer; }`,
  js:`document.querySelector('#action').addEventListener('click', () => {\n  document.querySelector('h1').textContent = 'Funcionou 🎉';\n});`
};

const storageKey = 'enterprise-educacional-state-v1';
const loadState = () => {
  try { return JSON.parse(localStorage.getItem(storageKey)) || {}; } catch { return {}; }
};
let state = Object.assign({ completedLessons:[], completedExercises:[], completedChallenges:[], completedProjects:[], lastLesson:'introducao', theme:'dark', playground:null }, loadState());
const saveState = () => localStorage.setItem(storageKey, JSON.stringify(state));

function route(){
  const hash = location.hash.replace('#','') || 'home';
  const pageName = hash.startsWith('aula') ? 'aula' : ['home','trilhas','exercicios','desafios','projetos','playground','glossario','progresso'].includes(hash) ? hash : 'home';
  $$('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===pageName));
  $$('.desktop-nav a').forEach(a=>a.classList.toggle('active',a.getAttribute('href')===`#${pageName}`));
  if(pageName==='aula') renderLesson(state.lastLesson);
  if(pageName==='progresso') renderProgress();
  window.scrollTo({top:0,behavior:'instant'});
}
window.addEventListener('hashchange', route);

function courseProgress(id){
  if(id!=='javascript') return 0;
  return Math.round((state.completedLessons.length / lessons.length)*100);
}
function overallProgress(){
  const lessonPart = state.completedLessons.length / lessons.length;
  const exercisePart = state.completedExercises.length / exercises.length;
  const challengePart = state.completedChallenges.length / challenges.length;
  const projectPart = state.completedProjects.length / projects.length;
  return Math.round((lessonPart*.5 + exercisePart*.25 + projectPart*.15 + challengePart*.10)*100);
}

function renderHome(){
  $('#homeTechGrid').innerHTML = courses.map(c=>`<a class="tech-card" href="#trilhas" data-course="${c.id}"><span class="tech-code">${c.code}</span><h3>${c.title}</h3><p>${c.description}</p><div class="card-foot"><span>${c.lessons} aulas</span><span>${courseProgress(c.id)}% →</span></div></a>`).join('');
  const p = overallProgress();
  $('#continuePercent').textContent=`${p}%`; $('#continueBar').style.width=`${p}%`;
  if(state.completedLessons.length){
    const next = lessons[Math.min(state.completedLessons.length, lessons.length-1)];
    $('#continueTitle').textContent=`Continue em ${next.title}`;
    $('#continueText').textContent='Seu progresso foi salvo neste navegador. Retome exatamente de onde parou.';
    $('#continueLabel').textContent='JavaScript — Fundamentos';
    $('#continueButton').textContent='Continuar aula'; $('#continueButton').href='#aula';
  }
}

function renderTracks(){
  $('#trackGrid').innerHTML = courses.map(c=>`<article class="track-card"><div class="track-top"><div><span class="eyebrow simple">${c.code}</span><h2>${c.title}</h2><p>${c.description}</p></div><div class="track-icon">${c.code}</div></div><div class="track-meta"><span>${c.modules.length} módulos</span><span>${c.lessons} aulas</span><span>Iniciante → Intermediário</span></div><div class="track-modules">${c.modules.map((m,i)=>`<div class="module-row"><span>${String(i+1).padStart(2,'0')} · ${m}</span><span>${i===0?'Disponível':'Em sequência'}</span></div>`).join('')}</div><div class="progress-label"><span>Progresso</span><strong>${courseProgress(c.id)}%</strong></div><div class="progress" style="margin:8px 0 18px"><span style="width:${courseProgress(c.id)}%"></span></div><a class="button ${c.id==='javascript'?'primary':'secondary'}" href="${c.id==='javascript'?'#aula':'#trilhas'}">${courseProgress(c.id)?'Continuar':'Começar trilha'}</a></article>`).join('');
}

function renderLesson(id='introducao'){
  const lesson = lessons.find(l=>l.id===id) || lessons[0]; state.lastLesson=lesson.id; saveState();
  const idx=lessons.indexOf(lesson); const done=state.completedLessons.includes(lesson.id);
  $('#lessonNav').innerHTML=lessons.map((l,i)=>`<button class="${l.id===lesson.id?'active ':''}${state.completedLessons.includes(l.id)?'done':''}" data-lesson="${l.id}"><span class="lesson-state">${state.completedLessons.includes(l.id)?'✓':i+1}</span><span>${l.title}</span></button>`).join('');
  $('#lessonCoursePercent').textContent=`${courseProgress('javascript')}%`; $('#lessonCourseBar').style.width=`${courseProgress('javascript')}%`;
  $('#lessonContent').innerHTML=`
    <div class="lesson-breadcrumb">Trilhas / JavaScript / Fundamentos / ${lesson.title}</div>
    <h1>${lesson.title}</h1><p class="lesson-intro">${lesson.intro}</p>
    <section class="lesson-section lesson-objectives"><h2>O que você vai aprender</h2><ul>${lesson.objectives.map(o=>`<li>${o}</li>`).join('')}</ul></section>
    <section class="lesson-section"><h2>Explicação</h2><p>${lesson.explanation}</p></section>
    <div class="code-block"><div class="code-head"><span>JavaScript</span><button class="text-button copy-example">Copiar</button></div><pre><code>${escapeHtml(lesson.code)}</code></pre></div>
    <section class="lesson-section"><h2>Resultado</h2><div class="callout"><strong>Saída</strong><p style="white-space:pre-line">${escapeHtml(lesson.result)}</p></div></section>
    <div class="callout"><strong>Boa prática</strong><p>${lesson.tip}</p></div>
    <div class="callout"><strong>Erro comum</strong><p>${lesson.error}</p></div>
    <section class="lesson-section"><h2>Teste você mesmo</h2><p>Altere o exemplo no Playground e observe o que muda. A prática transforma leitura em entendimento.</p><a class="button secondary" href="#playground" id="openLessonInPlayground">Abrir no Playground</a></section>
    <div class="lesson-actions"><div>${idx>0?`<button class="text-button lesson-prev" data-lesson="${lessons[idx-1].id}">← ${lessons[idx-1].title}</button>`:''}</div><button class="button ${done?'secondary':'primary'}" id="completeLesson">${done?'Aula concluída ✓':'Marcar como concluída'}</button><div class="next">${idx<lessons.length-1?`<button class="text-button lesson-next" data-lesson="${lessons[idx+1].id}">${lessons[idx+1].title} →</button>`:'<a class="text-link" href="#trilhas">Voltar para Trilhas →</a>'}</div></div>`;
  $$('.lesson-nav button').forEach(b=>b.onclick=()=>renderLesson(b.dataset.lesson));
  $$('.lesson-prev,.lesson-next').forEach(b=>b.onclick=()=>renderLesson(b.dataset.lesson));
  $('.copy-example').onclick=async()=>{await navigator.clipboard.writeText(lesson.code); $('.copy-example').textContent='Copiado'; setTimeout(()=>$('.copy-example').textContent='Copiar',1200)};
  $('#openLessonInPlayground').onclick=()=>{state.playground={...defaultPlayground,js:lesson.code};saveState();};
  $('#completeLesson').onclick=()=>{ if(!done){state.completedLessons.push(lesson.id)} else {state.completedLessons=state.completedLessons.filter(x=>x!==lesson.id)} saveState();renderLesson(lesson.id);renderHome(); };
}

let exerciseFilter='Todos', currentExercise=exercises[0].id;
function renderExercises(){
  const filters=['Todos','HTML','CSS','JavaScript','Python'];
  $('#exerciseFilters').innerHTML=filters.map(f=>`<button class="filter-chip ${f===exerciseFilter?'active':''}" data-filter="${f}">${f}</button>`).join('');
  $$('#exerciseFilters button').forEach(b=>b.onclick=()=>{exerciseFilter=b.dataset.filter;renderExercises()});
  const list=exerciseFilter==='Todos'?exercises:exercises.filter(e=>e.tech===exerciseFilter);
  if(!list.some(e=>e.id===currentExercise)) currentExercise=list[0]?.id;
  $('#exerciseList').innerHTML=list.map(e=>`<button class="${e.id===currentExercise?'active':''}" data-id="${e.id}"><small>${e.tech} · ${e.type}</small><strong>${e.title}</strong></button>`).join('');
  $$('#exerciseList button').forEach(b=>b.onclick=()=>{currentExercise=Number(b.dataset.id);renderExercises()});
  const ex=exercises.find(e=>e.id===currentExercise) || list[0];
  if(!ex){$('#exerciseCard').innerHTML='<div class="empty-state">Nenhum exercício neste filtro.</div>';return}
  const complete=state.completedExercises.includes(ex.id);
  $('#exerciseCard').innerHTML=`<span class="eyebrow simple">${ex.tech} · ${ex.type}</span><h2>${ex.title}</h2><p class="exercise-prompt">${ex.prompt}</p>${ex.options?`<div class="options">${ex.options.map(o=>`<button class="option" data-value="${escapeAttr(o)}">${o}</button>`).join('')}</div>`:`<textarea class="answer-input" id="exerciseAnswer" placeholder="Digite sua resposta..."></textarea>`}<button class="button primary" id="checkAnswer">Verificar resposta</button>${complete?'<div class="feedback success"><strong>Já concluído</strong><p>Você já acertou este exercício. Pode tentar novamente quando quiser.</p></div>':''}<div id="exerciseFeedback"></div>`;
  let selected=''; $$('.option',$('#exerciseCard')).forEach(o=>o.onclick=()=>{$$('.option',$('#exerciseCard')).forEach(x=>x.classList.remove('selected'));o.classList.add('selected');selected=o.dataset.value});
  $('#checkAnswer').onclick=()=>{
    const raw=ex.options?selected:($('#exerciseAnswer')?.value||'');
    const norm=v=>String(v).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ');
    const correct=ex.normalize?norm(raw)===norm(ex.answer):norm(raw)===norm(ex.answer);
    $('#exerciseFeedback').innerHTML=`<div class="feedback ${correct?'success':'error'}"><strong>${correct?'Correto':'Ainda não'}</strong><p>${correct?ex.explanation:`Revise o conceito e tente novamente. ${ex.explanation}`}</p></div>`;
    if(correct&&!state.completedExercises.includes(ex.id)){state.completedExercises.push(ex.id);saveState();renderHome();}
  }
}

function renderChallenges(){
  $('#challengeGrid').innerHTML=challenges.map((c,i)=>`<article class="challenge-card"><div class="badge-row"><span class="badge">${c.tech}</span><span class="badge">${c.level}</span></div><h2>${c.title}</h2><p>${c.description}</p><div class="card-bottom"><button class="button secondary hint-button" data-id="${i}">Mostrar dica 1</button><div class="hint-box" id="hint-${i}" hidden></div></div></article>`).join('');
  $$('.hint-button').forEach(btn=>{let n=0;btn.onclick=()=>{const c=challenges[Number(btn.dataset.id)], box=$(`#hint-${btn.dataset.id}`);box.hidden=false;if(n<c.hints.length){box.innerHTML=`<strong>Dica ${n+1}</strong><p>${c.hints[n]}</p>`;n++;btn.textContent=n<c.hints.length?`Mostrar dica ${n+1}`:'Mostrar solução'}else{box.innerHTML=`<strong>Solução</strong><p>${c.solution}</p>`;btn.disabled=true;btn.textContent='Solução exibida';if(!state.completedChallenges.includes(c.title)){state.completedChallenges.push(c.title);saveState();renderHome();}}}}
  )
}

function renderProjects(){
  $('#projectGrid').innerHTML=projects.map((p,i)=>`<article class="project-card"><div class="badge-row">${p.tech.map(t=>`<span class="badge">${t}</span>`).join('')}<span class="badge">${p.level}</span></div><h2>${p.title}</h2><p>${p.description}</p><div class="track-modules">${p.steps.map((s,j)=>`<label class="module-row"><span><input type="checkbox" class="project-step" data-project="${i}" data-step="${j}"> ${s}</span><span>${j+1}/${p.steps.length}</span></label>`).join('')}</div><div class="card-bottom"><button class="button secondary project-complete" data-project="${i}">${state.completedProjects.includes(p.title)?'Projeto concluído ✓':'Marcar projeto concluído'}</button></div></article>`).join('');
  $$('.project-complete').forEach(b=>b.onclick=()=>{const p=projects[Number(b.dataset.project)];if(state.completedProjects.includes(p.title))state.completedProjects=state.completedProjects.filter(x=>x!==p.title);else state.completedProjects.push(p.title);saveState();renderProjects();renderHome();});
}

let activeLang='html'; let pg={...defaultPlayground};
function initPlayground(){
  pg={...defaultPlayground,...(state.playground||{})}; activeLang='html'; updateEditor(); runPlayground();
  $$('#editorTabs button').forEach(b=>b.onclick=()=>{pg[activeLang]=$('#codeEditor').value;activeLang=b.dataset.lang;$$('#editorTabs button').forEach(x=>x.setAttribute('aria-selected',x===b?'true':'false'));updateEditor()});
  $('#codeEditor').addEventListener('input',()=>{pg[activeLang]=$('#codeEditor').value;state.playground={...pg};saveState()});
  $('#runPlayground').onclick=runPlayground;
  $('#resetPlayground').onclick=()=>{pg={...defaultPlayground};state.playground={...pg};saveState();updateEditor();runPlayground()};
  $('#copyCode').onclick=async()=>{await navigator.clipboard.writeText($('#codeEditor').value);$('#copyCode').textContent='Copiado';setTimeout(()=>$('#copyCode').textContent='Copiar',1200)};
}
function updateEditor(){$('#codeEditor').value=pg[activeLang]||''}
function runPlayground(){pg[activeLang]=$('#codeEditor')?.value??pg[activeLang];const doc=`<!doctype html><html><head><meta charset="utf-8"><style>${pg.css}</style></head><body>${pg.html}<script>window.onerror=function(m,s,l,c){document.body.insertAdjacentHTML('beforeend','<pre style="color:#b00020;background:#fff0f0;padding:12px">Erro: '+String(m).replace(/</g,'&lt;')+'</pre>')};${pg.js}<\/script></body></html>`;$('#previewFrame').srcdoc=doc;$('#runStatus').textContent='Executado agora';setTimeout(()=>$('#runStatus').textContent='Pronto',1800);state.playground={...pg};saveState()}

let selectedTerm=glossary[0].term, letterFilter='Todos';
function renderGlossary(){
  const letters=['Todos',...[...new Set(glossary.map(g=>g.term[0].toUpperCase()))]];
  $('#alphabet').innerHTML=letters.map(l=>`<button class="${letterFilter===l?'active':''}" data-letter="${l}" aria-label="${l==='Todos'?'Todos os termos':`Termos com ${l}`}">${l==='Todos'?'•':l}</button>`).join('');
  $$('#alphabet button').forEach(b=>b.onclick=()=>{letterFilter=b.dataset.letter;renderGlossary()});
  const q=($('#glossarySearch').value||'').toLowerCase();const filtered=glossary.filter(g=>(letterFilter==='Todos'||g.term[0].toUpperCase()===letterFilter)&&(!q||(`${g.term} ${g.definition}`).toLowerCase().includes(q)));
  if(!filtered.some(g=>g.term===selectedTerm)) selectedTerm=filtered[0]?.term;
  $('#glossaryList').innerHTML=filtered.length?filtered.map(g=>`<button class="${g.term===selectedTerm?'active':''}" data-term="${g.term}">${g.term}</button>`).join(''):'<div class="empty-state">Nenhum termo encontrado.</div>';
  $$('#glossaryList button').forEach(b=>b.onclick=()=>{selectedTerm=b.dataset.term;renderGlossary()});
  const term=glossary.find(g=>g.term===selectedTerm);$('#glossaryDetail').innerHTML=term?`<span class="term-type">${term.category}</span><h2>${term.term}</h2><p class="definition">${term.definition}</p><section><h3>Entenda melhor</h3><p>${term.detail}</p></section><section><h3>Continue estudando</h3><p>Procure este conceito nas aulas e pratique em exercícios relacionados para fixar o significado.</p><a class="button secondary" href="#trilhas">Explorar trilhas</a></section>`:'<div class="empty-state">Selecione um termo.</div>';
}

function renderProgress(){
  const total=overallProgress();
  $('#progressSummary').innerHTML=`<div class="summary-card primary"><span class="label">Progresso geral</span><strong>${total}%</strong><div class="progress"><span style="width:${total}%"></span></div></div><div class="summary-card"><span class="label">Aulas</span><strong>${state.completedLessons.length}</strong><span class="text-muted">de ${lessons.length}</span></div><div class="summary-card"><span class="label">Exercícios</span><strong>${state.completedExercises.length}</strong><span class="text-muted">de ${exercises.length}</span></div><div class="summary-card"><span class="label">Projetos</span><strong>${state.completedProjects.length}</strong><span class="text-muted">de ${projects.length}</span></div>`;
  $('#progressGrid').innerHTML=`${courses.map(c=>`<article class="progress-card"><div class="progress-card-head"><h2>${c.title}</h2><strong>${courseProgress(c.id)}%</strong></div><div class="progress"><span style="width:${courseProgress(c.id)}%"></span></div><div class="recent-list"><div class="recent-item"><span>Módulos</span><span>${c.modules.length}</span></div><div class="recent-item"><span>Aulas previstas</span><span>${c.lessons}</span></div></div></article>`).join('')}<article class="progress-card"><div class="progress-card-head"><h2>Atividade recente</h2></div><div class="recent-list">${state.completedLessons.slice(-3).reverse().map(id=>`<div class="recent-item"><span>Aula concluída: ${lessons.find(l=>l.id===id)?.title||id}</span><span>JavaScript</span></div>`).join('')||'<div class="empty-state">Conclua sua primeira aula para começar o histórico.</div>'}</div></article><article class="progress-card"><div class="progress-card-head"><h2>Próximo passo</h2></div><p class="text-muted">${state.completedLessons.length<lessons.length?`Continue em <strong>${lessons[Math.min(state.completedLessons.length,lessons.length-1)].title}</strong> para avançar em Fundamentos de JavaScript.`:'Você concluiu as aulas disponíveis desta trilha. Explore exercícios e projetos.'}</p><a class="button secondary" href="${state.completedLessons.length<lessons.length?'#aula':'#exercicios'}">Continuar</a></article>`;
}

function initSearch(){
  const dialog=$('#searchDialog'), input=$('#globalSearch');
  $('#openSearch').onclick=()=>{dialog.showModal();setTimeout(()=>input.focus(),20);renderSearch('')};
  input.addEventListener('input',()=>renderSearch(input.value));
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
}
function renderSearch(q){
  const items=[...lessons.map(l=>({type:'Aula',title:l.title,desc:'JavaScript → Fundamentos',href:'#aula'})),...projects.map(p=>({type:'Projeto',title:p.title,desc:p.tech.join(' · '),href:'#projetos'})),...glossary.map(g=>({type:'Glossário',title:g.term,desc:g.definition,href:'#glossario'}))];
  const norm=q.trim().toLowerCase(); const res=norm?items.filter(i=>(`${i.title} ${i.desc}`).toLowerCase().includes(norm)).slice(0,10):items.slice(0,8);
  $('#searchResults').innerHTML=res.length?res.map(i=>`<a class="search-result" href="${i.href}" data-search-close><small>${i.type} · ${i.desc}</small><strong>${i.title}</strong></a>`).join(''):'<div class="empty-state">Nenhum resultado encontrado.</div>';
  $$('[data-search-close]').forEach(a=>a.onclick=()=>$('#searchDialog').close());
}

function syncThemeBrandAssets(theme){
  const isLight = theme === 'light';

  $$('.brand-symbol').forEach(img => {
    const darkSrc = img.dataset.darkSrc || img.getAttribute('src');
    const lightSrc = img.dataset.lightSrc || darkSrc;
    const nextSrc = isLight ? lightSrc : darkSrc;
    if (img.getAttribute('src') !== nextSrc) img.setAttribute('src', nextSrc);
  });

  const favicon32 = $('#favicon32');
  const favicon16 = $('#favicon16');
  const appleTouchIcon = $('#appleTouchIcon');
  if (favicon32) favicon32.href = isLight ? favicon32.dataset.lightHref : favicon32.dataset.darkHref;
  if (favicon16) favicon16.href = isLight ? favicon16.dataset.lightHref : favicon16.dataset.darkHref;
  if (appleTouchIcon) appleTouchIcon.href = isLight ? appleTouchIcon.dataset.lightHref : appleTouchIcon.dataset.darkHref;

  const themeMeta = $('meta[name="theme-color"]');
  if (themeMeta) themeMeta.content = isLight ? '#ddd6ce' : '#08090a';
  $('#themeToggle')?.setAttribute('aria-label', isLight ? 'Ativar tema escuro' : 'Ativar tema claro');
}

function applyTheme(theme, { animate = false } = {}){
  const root = document.documentElement;
  if (animate) {
    root.classList.remove('theme-switching');
    void root.offsetWidth;
    root.classList.add('theme-switching');
    window.clearTimeout(applyTheme._cleanupTimer);
    applyTheme._cleanupTimer = window.setTimeout(() => root.classList.remove('theme-switching'), 520);
  }
  root.dataset.theme = theme;
  syncThemeBrandAssets(theme);
}

function initTheme(){
  const initialTheme = state.theme === 'light' || state.theme === 'dark'
    ? state.theme
    : document.documentElement.dataset.theme || 'dark';
  applyTheme(initialTheme);

  $('#themeToggle').onclick = () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    state.theme = next;
    applyTheme(next, { animate: true });
    saveState();
  };
}
function initMobileMenu(){
  const btn=$('#mobileMenuButton'),nav=$('#mobileNav'); btn.onclick=()=>{const open=btn.getAttribute('aria-expanded')==='true';btn.setAttribute('aria-expanded',String(!open));nav.hidden=open}; $$('#mobileNav a').forEach(a=>a.onclick=()=>{nav.hidden=true;btn.setAttribute('aria-expanded','false')});
}

function escapeHtml(str=''){return str.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function escapeAttr(str=''){return String(str).replace(/&/g,'&amp;').replace(/"/g,'&quot;')}

function init(){
  initTheme();initMobileMenu();initSearch();renderHome();renderTracks();renderExercises();renderChallenges();renderProjects();renderGlossary();initPlayground();renderProgress();route();
  $('#glossarySearch').addEventListener('input',renderGlossary);
  $('#resetProgress').onclick=()=>{if(confirm('Redefinir todo o progresso salvo neste navegador?')){state.completedLessons=[];state.completedExercises=[];state.completedChallenges=[];state.completedProjects=[];saveState();renderProgress();renderHome();renderTracks();renderExercises();renderProjects();}};
}
init();
