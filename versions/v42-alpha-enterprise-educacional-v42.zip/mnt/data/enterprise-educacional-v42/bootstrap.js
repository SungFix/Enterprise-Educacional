initPlatformFeatures();
init();
