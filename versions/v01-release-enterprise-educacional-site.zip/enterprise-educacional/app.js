const $ = (s, scope = document) => scope.querySelector(s);
const $$ = (s, scope = document) => [...scope.querySelectorAll(s)];

const content = window.EE_CONTENT || { courses:[], lessons:[], exercises:[], challenges:[], projects:[], glossary:[] };
const { courses, lessons, exercises, challenges, projects, glossary } = content;
const courseIconMap = { html:'html', css:'css', javascript:'js', python:'python' };
const techNameToCourse = { HTML:'html', CSS:'css', JavaScript:'javascript', Python:'python' };
const iconSvg = (name, extraClass='') => `<svg class="ui-icon ${extraClass}" aria-hidden="true"><use href="#icon-${name}"></use></svg>`;
const normalizeText = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const escapeHtml = (str='') => String(str).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const escapeAttr = (str='') => String(str).replace(/&/g,'&amp;').replace(/"/g,'&quot;');
const slugify = text => normalizeText(text).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');

const courseById = id => courses.find(course => course.id === id);
const lessonsForCourse = courseId => lessons.filter(lesson => lesson.courseId === courseId).sort((a,b)=>a.order-b.order);
const lessonById = id => lessons.find(lesson => lesson.id === id);
const lessonBySlug = (courseId, slug) => lessons.find(lesson => lesson.courseId === courseId && lesson.slug === slug);
const lessonHref = lesson => `#aula/${lesson.courseId}/${lesson.slug}`;
const firstLesson = courseId => lessonsForCourse(courseId)[0];
const techLabel = courseId => courseById(courseId)?.title || courseId;

const defaultPlayground = {
  html:`<main class="card">\n  <span class="tag">Enterprise Educacional</span>\n  <h1>Seu código, seu resultado.</h1>\n  <p>Edite este exemplo e clique em Executar.</p>\n  <button id="action">Testar JavaScript</button>\n</main>`,
  css:`body {\n  margin: 0;\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  font-family: system-ui, sans-serif;\n  background: #f4f4f4;\n  color: #151515;\n}\n.card {\n  width: min(520px, 86vw);\n  padding: 32px;\n  border: 1px solid #d7d7d7;\n  border-radius: 18px;\n  background: white;\n}\n.tag { font-size: 12px; color: #666; }\nbutton { padding: 10px 14px; cursor: pointer; }`,
  js:`document.querySelector('#action').addEventListener('click', () => {\n  document.querySelector('h1').textContent = 'Funcionou 🎉';\n});`
};

const storageKey = 'enterprise-educacional-state-v2';
const legacyStorageKey = 'enterprise-educacional-state-v1';
const loadState = () => {
  try {
    return JSON.parse(localStorage.getItem(storageKey)) || JSON.parse(localStorage.getItem(legacyStorageKey)) || {};
  } catch { return {}; }
};

const defaultLast = firstLesson('javascript')?.id || lessons[0]?.id || '';
let state = Object.assign({
  completedLessons:[], completedExercises:[], completedChallenges:[], completedProjects:[], projectSteps:{},
  lastLesson:defaultLast, theme:'dark', playground:null
}, loadState());
if(!Array.isArray(state.completedLessons)) state.completedLessons=[];
if(!Array.isArray(state.completedExercises)) state.completedExercises=[];
if(!Array.isArray(state.completedChallenges)) state.completedChallenges=[];
if(!Array.isArray(state.completedProjects)) state.completedProjects=[];
if(!state.projectSteps || typeof state.projectSteps !== 'object') state.projectSteps={};

function migrateLegacyState(){
  const legacyMap = {
    introducao: lessons.find(l=>l.courseId==='javascript' && normalizeText(l.title).includes('o que e javascript'))?.id,
    variaveis: lessons.find(l=>l.courseId==='javascript' && l.title==='let')?.id,
    tipos: lessons.find(l=>l.courseId==='javascript' && l.title==='String')?.id,
    condicionais: lessons.find(l=>l.courseId==='javascript' && l.title==='if')?.id,
  };
  state.completedLessons = [...new Set(state.completedLessons.map(id=>lessonById(id)?id:legacyMap[id]).filter(Boolean))];
  if(!lessonById(state.lastLesson)) state.lastLesson = legacyMap[state.lastLesson] || defaultLast;
  state.completedProjects = [...new Set(state.completedProjects.map(value=>projects.find(p=>p.id===value || p.title===value)?.id).filter(Boolean))];
  state.completedChallenges = [...new Set(state.completedChallenges.map(value=>challenges.find(c=>c.id===value || c.title===value)?.id).filter(Boolean))];
}
migrateLegacyState();
const saveState = () => { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* armazenamento indisponível: a sessão continua funcional */ } };
saveState();

function parseRoute(){
  const raw = decodeURIComponent(location.hash.replace(/^#/,'') || 'home');
  const parts = raw.split('/').filter(Boolean);
  const root = parts[0] || 'home';
  const allowed = ['home','trilhas','aula','exercicios','desafios','projetos','playground','glossario','progresso'];
  return { page: allowed.includes(root) ? root : 'home', parts };
}

function route(){
  const { page, parts } = parseRoute();
  document.body.dataset.page = page;
  $$('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===page));
  $$('.desktop-nav a, .mobile-nav a').forEach(a=>a.classList.toggle('active',a.getAttribute('href')===`#${page}`));
  if(page==='aula'){
    const requestedCourse = parts[1];
    const requestedSlug = parts[2];
    const direct = requestedCourse && requestedSlug ? lessonBySlug(requestedCourse,requestedSlug) : null;
    renderLesson(direct?.id || state.lastLesson || defaultLast);
  }
  if(page==='glossario'){
    if(parts[1]) selectedTerm = glossary.find(g=>slugify(g.term)===parts[1])?.term || selectedTerm;
    renderGlossary();
  }
  if(page==='exercicios'){
    if(parts[1] && exercises.some(ex=>String(ex.id)===parts[1])) currentExercise=parts[1];
    renderExercises();
  }
  if(page==='progresso') renderProgress();
  if(page!=='aula'){
    const titles={home:'Enterprise Educacional',trilhas:'Trilhas | Enterprise Educacional',exercicios:'Exercícios | Enterprise Educacional',desafios:'Desafios | Enterprise Educacional',projetos:'Projetos | Enterprise Educacional',playground:'Playground | Enterprise Educacional',glossario:'Glossário | Enterprise Educacional',progresso:'Progresso | Enterprise Educacional'};
    document.title=titles[page]||'Enterprise Educacional';
  }
  window.scrollTo({top:0,behavior:'instant'});
}
window.addEventListener('hashchange', route);

function completedLessonsForCourse(courseId){
  const valid = new Set(lessonsForCourse(courseId).map(l=>l.id));
  return state.completedLessons.filter(id=>valid.has(id));
}
function courseProgress(courseId){
  const total = lessonsForCourse(courseId).length;
  return total ? Math.round((completedLessonsForCourse(courseId).length / total)*100) : 0;
}
function overallProgress(){
  const lessonPart = lessons.length ? state.completedLessons.filter(id=>lessonById(id)).length / lessons.length : 0;
  const exercisePart = exercises.length ? state.completedExercises.length / exercises.length : 0;
  const challengePart = challenges.length ? state.completedChallenges.length / challenges.length : 0;
  const projectPart = projects.length ? state.completedProjects.length / projects.length : 0;
  return Math.round((lessonPart*.5 + exercisePart*.25 + projectPart*.15 + challengePart*.10)*100);
}
function getProjectSteps(project){
  const stored = Array.isArray(state.projectSteps[project.id]) ? state.projectSteps[project.id] : (Array.isArray(state.projectSteps[project.title]) ? state.projectSteps[project.title] : []);
  return project.steps.map((_,index)=>Boolean(stored[index]));
}
function projectStepProgress(project){
  const steps = getProjectSteps(project);
  return steps.length ? Math.round((steps.filter(Boolean).length/steps.length)*100) : 0;
}
function isProjectDone(project){ return state.completedProjects.includes(project.id); }
function isChallengeDone(challenge){ return state.completedChallenges.includes(challenge.id); }
function nextLessonAfter(lesson){
  const list = lessonsForCourse(lesson.courseId);
  const index = list.findIndex(item=>item.id===lesson.id);
  return index>=0 ? list[index+1] || null : null;
}
function previousLessonBefore(lesson){
  const list = lessonsForCourse(lesson.courseId);
  const index = list.findIndex(item=>item.id===lesson.id);
  return index>0 ? list[index-1] : null;
}
function nextUncompletedLesson(courseId){
  const list = lessonsForCourse(courseId);
  return list.find(lesson=>!state.completedLessons.includes(lesson.id)) || list[0] || null;
}

function renderHome(){
  $('#homeTechGrid').innerHTML = courses.map(c=>{
    const first = firstLesson(c.id);
    return `<a class="tech-card" href="${first?lessonHref(first):'#trilhas'}"><span class="tech-icon">${iconSvg(courseIconMap[c.id])}</span><span class="tech-label">${c.code}</span><h3>${c.title}</h3><p>${c.description}</p><div class="card-foot"><span>${c.modules.length} módulos · ${c.lessons} aulas</span><span>${courseProgress(c.id)}% ${iconSvg('arrow-up-right','mini-icon')}</span></div></a>`;
  }).join('');

  const p=overallProgress();
  $('#continuePercent').textContent=`${p}%`; $('#continueBar').style.width=`${p}%`;
  const last=lessonById(state.lastLesson);
  if(last && state.completedLessons.length){
    const next = nextUncompletedLesson(last.courseId) || last;
    $('#continueTitle').textContent=`Continue em ${next.title}`;
    $('#continueText').textContent=`${techLabel(next.courseId)} → ${next.moduleTitle}. Seu progresso está salvo neste navegador.`;
    $('#continueLabel').textContent=`${techLabel(next.courseId)} — ${next.moduleTitle}`;
    $('#continueButton').textContent='Continuar aula'; $('#continueButton').href=lessonHref(next);
  } else {
    $('#continueTitle').textContent='Seu próximo passo está aqui.';
    $('#continueText').textContent=`Escolha entre ${lessons.length} aulas distribuídas em HTML, CSS, JavaScript e Python.`;
    $('#continueLabel').textContent='Progresso geral';
    $('#continueButton').textContent='Explorar trilhas'; $('#continueButton').href='#trilhas';
  }
}

function renderTracks(){
  $('#trackGrid').innerHTML = courses.map(c=>{
    const progress=courseProgress(c.id);
    const first=nextUncompletedLesson(c.id) || firstLesson(c.id);
    return `<article class="track-card"><div class="track-top"><div><span class="eyebrow simple">${c.code}</span><h2>${c.title}</h2><p>${c.description}</p></div><div class="track-icon">${iconSvg(courseIconMap[c.id])}</div></div><div class="track-meta"><span>${c.modules.length} módulos</span><span>${c.lessons} aulas</span><span>${c.level}</span></div><div class="track-modules">${c.modules.map((m,i)=>{
      const moduleFirst=lessonById(m.lessonIds[0]);
      return `<a class="module-row module-link" href="${moduleFirst?lessonHref(moduleFirst):'#trilhas'}"><span>${String(i+1).padStart(2,'0')} · ${m.title}</span><span>${m.lessonIds.length} aulas →</span></a>`;
    }).join('')}</div><div class="progress-label"><span>Progresso</span><strong>${progress}%</strong></div><div class="progress" style="margin:8px 0 18px"><span style="width:${progress}%"></span></div><a class="button ${progress?'secondary':'primary'}" href="${first?lessonHref(first):'#trilhas'}">${progress?'Continuar trilha':'Começar trilha'}</a></article>`;
  }).join('');
}

function renderLesson(id){
  const lesson=lessonById(id) || lessonById(defaultLast) || lessons[0];
  if(!lesson) return;
  state.lastLesson=lesson.id; saveState();
  const course=courseById(lesson.courseId);
  const list=lessonsForCourse(lesson.courseId);
  const idx=list.findIndex(l=>l.id===lesson.id);
  const previous=previousLessonBefore(lesson), next=nextLessonAfter(lesson);
  const done=state.completedLessons.includes(lesson.id);

  const sidebar=$('.lesson-sidebar');
  if(!$('#courseMenuToggle',sidebar)) sidebar.insertAdjacentHTML('afterbegin',`<button class="course-menu-toggle" id="courseMenuToggle" type="button" aria-expanded="false"><span>Conteúdo do curso</span><strong>${course.title}</strong></button>`);
  const menuToggle=$('#courseMenuToggle',sidebar);
  menuToggle.querySelector('strong').textContent=course.title;
  menuToggle.onclick=()=>{const open=sidebar.classList.toggle('mobile-open');menuToggle.setAttribute('aria-expanded',String(open));};
  $('.sidebar-heading .eyebrow').textContent=course.title;
  $('.sidebar-heading h2').textContent=lesson.moduleTitle;
  $('#lessonNav').innerHTML=course.modules.map((module,moduleIndex)=>{
    const moduleLessons=module.lessonIds.map(lessonById).filter(Boolean);
    const completed=moduleLessons.filter(l=>state.completedLessons.includes(l.id)).length;
    const open=module.id===lesson.moduleId;
    return `<details class="lesson-module" ${open?'open':''}><summary><span><small>${String(moduleIndex+1).padStart(2,'0')}</small>${module.title}</span><strong>${completed}/${moduleLessons.length}</strong></summary><div class="lesson-module-list">${moduleLessons.map((l,i)=>`<a class="${l.id===lesson.id?'active ':''}${state.completedLessons.includes(l.id)?'done':''}" href="${lessonHref(l)}"><span class="lesson-state">${state.completedLessons.includes(l.id)?'✓':i+1}</span><span>${l.title}</span></a>`).join('')}</div></details>`;
  }).join('');
  $('#lessonCoursePercent').textContent=`${courseProgress(course.id)}%`; $('#lessonCourseBar').style.width=`${courseProgress(course.id)}%`;

  const relatedExercises=exercises.filter(ex=>ex.relatedLessonId===lesson.id).slice(0,3);
  const relatedTerms=glossary.filter(term=>(term.relatedLessonIds||[]).includes(lesson.id)).slice(0,5);
  const languageLabel=course.id==='javascript'?'JavaScript':course.title;
  const editorAction=lesson.editor ? `<a class="button secondary" href="#playground" id="openLessonInPlayground">Abrir exemplo no Playground</a>` : `<a class="button secondary" href="#exercicios">Praticar em exercícios</a>`;

  $('#lessonContent').innerHTML=`
    <div class="lesson-breadcrumb"><a href="#trilhas">Trilhas</a> / ${course.title} / ${lesson.moduleTitle} / ${lesson.title}</div>
    <div class="lesson-title-row"><div><span class="eyebrow simple">Aula ${idx+1} de ${list.length}</span><h1>${lesson.title}</h1><p class="lesson-intro">${lesson.intro}</p></div><div class="lesson-position"><strong>${courseProgress(course.id)}%</strong><span>da trilha concluída</span></div></div>
    <section class="lesson-section lesson-objectives"><h2>O que você vai aprender</h2><ul>${lesson.objectives.map(o=>`<li>${o}</li>`).join('')}</ul></section>
    <section class="lesson-section"><h2>Explicação</h2><p>${lesson.explanation}</p>${lesson.deepDive?lesson.deepDive.split(/\n\n+/).map(paragraph=>`<p>${paragraph}</p>`).join(''):''}<div class="lesson-practical-context"><strong>Por que isso importa</strong><p>${lesson.practicalContext||lesson.summary}</p></div><div class="lesson-analogy"><strong>Uma forma de pensar</strong><p>${lesson.analogy}</p></div></section>
    <section class="lesson-section"><h2>Sintaxe essencial</h2><div class="code-block compact-code"><div class="code-head"><span>${languageLabel}</span><button class="text-button copy-syntax">Copiar</button></div><pre><code>${escapeHtml(lesson.syntax)}</code></pre></div></section>
    <section class="lesson-section"><h2>Exemplo</h2><div class="code-block"><div class="code-head"><span>${languageLabel}</span><button class="text-button copy-example">Copiar</button></div><pre><code>${escapeHtml(lesson.code)}</code></pre></div></section>
    <section class="lesson-section"><h2>Resultado</h2><div class="callout output-callout"><strong>Saída ou efeito esperado</strong><p style="white-space:pre-line">${escapeHtml(lesson.result)}</p></div></section>
    <section class="lesson-section"><h2>Entenda o código</h2><ol class="understand-list">${lesson.understand.map(item=>`<li>${item}</li>`).join('')}</ol></section>
    <section class="lesson-section"><h2>Erros comuns</h2><div class="error-grid">${lesson.errors.map(item=>`<div class="callout"><strong>Evite isto</strong><p>${item}</p></div>`).join('')}</div></section>
    <div class="callout practice-tip"><strong>Boa prática</strong><p>${lesson.tip}</p></div>
    <section class="lesson-section practice-section"><h2>Teste você mesmo</h2><p>${lesson.practice}</p>${editorAction}</section>
    ${relatedExercises.length?`<section class="lesson-section"><h2>Exercícios relacionados</h2><div class="related-grid">${relatedExercises.map(ex=>`<a href="#exercicios/${encodeURIComponent(ex.id)}" class="related-card"><small>${ex.difficulty} · ${ex.type}</small><strong>${ex.title}</strong></a>`).join('')}</div></section>`:''}
    ${relatedTerms.length?`<section class="lesson-section"><h2>Conceitos relacionados</h2><div class="related-tags">${relatedTerms.map(term=>`<a href="#glossario/${slugify(term.term)}">${term.term}</a>`).join('')}</div></section>`:''}
    ${lesson.checkpoint?.length?`<section class="lesson-section checkpoint-section"><h2>Antes de avançar</h2><ul>${lesson.checkpoint.map(item=>`<li>${item}</li>`).join('')}</ul></section>`:''}
    <section class="lesson-section lesson-summary"><h2>Resumo</h2><p>${lesson.summary}</p><p><strong>Próximo passo:</strong> ${lesson.nextStep}</p></section>
    <div class="lesson-actions"><div>${previous?`<a class="text-button lesson-link" href="${lessonHref(previous)}">← ${previous.title}</a>`:''}</div><button class="button ${done?'secondary':'primary'}" id="completeLesson">${done?'Aula concluída ✓':'Marcar como concluída'}</button><div class="next">${next?`<a class="text-button lesson-link" href="${lessonHref(next)}">${next.title} →</a>`:'<a class="text-link" href="#trilhas">Voltar para Trilhas →</a>'}</div></div>`;

  $('.copy-example').onclick=async()=>copyWithFeedback($('.copy-example'),lesson.code);
  $('.copy-syntax').onclick=async()=>copyWithFeedback($('.copy-syntax'),lesson.syntax);
  if(lesson.editor && $('#openLessonInPlayground')) $('#openLessonInPlayground').onclick=()=>{ state.playground={...defaultPlayground,...lesson.editor}; saveState(); };
  $('#completeLesson').onclick=()=>{
    if(done) state.completedLessons=state.completedLessons.filter(x=>x!==lesson.id);
    else state.completedLessons=[...new Set([...state.completedLessons,lesson.id])];
    saveState(); renderLesson(lesson.id); renderHome(); renderTracks();
  };
  document.title=`${lesson.title} — ${course.title} | Enterprise Educacional`;
}

async function copyWithFeedback(button,text){
  try { await navigator.clipboard.writeText(text); button.textContent='Copiado'; setTimeout(()=>button.textContent='Copiar',1200); }
  catch { button.textContent='Não foi possível copiar'; setTimeout(()=>button.textContent='Copiar',1800); }
}

let exerciseTechFilter='Todos', exerciseDifficultyFilter='Todos', exerciseTypeFilter='Todos', exerciseQuery='', currentExercise=exercises[0]?.id, exerciseLimit=36;
function renderExercises(){
  const techFilters=['Todos','HTML','CSS','JavaScript','Python'];
  const difficulties=['Todos','Iniciante','Fácil','Médio','Difícil'];
  const types=['Todos',...new Set(exercises.map(e=>e.type))];
  $('#exerciseFilters').innerHTML=`<div class="filter-group"><span>Tecnologia</span>${techFilters.map(f=>`<button class="filter-chip ${f===exerciseTechFilter?'active':''}" data-tech="${f}">${f}</button>`).join('')}</div><div class="filter-group"><label>Dificuldade<select id="exerciseDifficulty">${difficulties.map(d=>`<option ${d===exerciseDifficultyFilter?'selected':''}>${d}</option>`).join('')}</select></label><label>Tipo<select id="exerciseType">${types.map(t=>`<option ${t===exerciseTypeFilter?'selected':''}>${t}</option>`).join('')}</select></label><label class="exercise-search">Buscar<input id="exerciseSearch" type="search" value="${escapeAttr(exerciseQuery)}" placeholder="Ex.: flexbox, arrays..."></label></div>`;
  $$('[data-tech]',$('#exerciseFilters')).forEach(btn=>btn.onclick=()=>{exerciseTechFilter=btn.dataset.tech;exerciseLimit=36;renderExercises()});
  $('#exerciseDifficulty').onchange=e=>{exerciseDifficultyFilter=e.target.value;exerciseLimit=36;renderExercises()};
  $('#exerciseType').onchange=e=>{exerciseTypeFilter=e.target.value;exerciseLimit=36;renderExercises()};
  $('#exerciseSearch').oninput=e=>{exerciseQuery=e.target.value;exerciseLimit=36;renderExerciseListOnly()};
  renderExerciseListOnly();
}
function filteredExercises(){
  const q=normalizeText(exerciseQuery.trim());
  return exercises.filter(e=>(exerciseTechFilter==='Todos'||e.tech===exerciseTechFilter)&&(exerciseDifficultyFilter==='Todos'||e.difficulty===exerciseDifficultyFilter)&&(exerciseTypeFilter==='Todos'||e.type===exerciseTypeFilter)&&(!q||normalizeText(`${e.title} ${e.prompt} ${e.tech} ${e.type} ${e.difficulty}`).includes(q)));
}
function renderExerciseListOnly(){
  const list=filteredExercises();
  if(!list.some(e=>e.id===currentExercise)) currentExercise=list[0]?.id;
  const visible=list.slice(0,exerciseLimit);
  $('#exerciseList').innerHTML=visible.length?`${visible.map(e=>`<button class="${e.id===currentExercise?'active':''}" data-id="${escapeAttr(e.id)}"><small>${e.tech} · ${e.difficulty} · ${e.type}</small><strong>${e.title}</strong></button>`).join('')}${list.length>visible.length?`<button class="load-more" id="loadMoreExercises">Mostrar mais (${list.length-visible.length})</button>`:''}`:'<div class="empty-state">Nenhum exercício encontrado com esses filtros.</div>';
  $$('#exerciseList button[data-id]').forEach(btn=>btn.onclick=()=>{currentExercise=btn.dataset.id;renderExerciseListOnly()});
  if($('#loadMoreExercises')) $('#loadMoreExercises').onclick=()=>{exerciseLimit+=36;renderExerciseListOnly()};
  renderExerciseCard(list.find(e=>e.id===currentExercise));
}
function renderExerciseCard(ex){
  if(!ex){ $('#exerciseCard').innerHTML='<div class="empty-state">Selecione ou filtre um exercício.</div>'; return; }
  const complete=state.completedExercises.includes(ex.id);
  $('#exerciseCard').innerHTML=`<div class="badge-row"><span class="badge">${ex.tech}</span><span class="badge">${ex.difficulty}</span><span class="badge">${ex.type}</span></div><h2>${ex.title}</h2><p class="exercise-prompt">${ex.prompt}</p>${ex.options?`<div class="options">${ex.options.map(o=>`<button class="option" data-value="${escapeAttr(o)}">${escapeHtml(o)}</button>`).join('')}</div>`:`<textarea class="answer-input" id="exerciseAnswer" placeholder="Digite sua resposta..."></textarea>`}<button class="button primary" id="checkAnswer">Verificar resposta</button>${complete?'<div class="feedback success"><strong>Já concluído</strong><p>Você já acertou este exercício. Refaça para revisar quando quiser.</p></div>':''}<div id="exerciseFeedback"></div>`;
  let selected='';
  $$('.option',$('#exerciseCard')).forEach(option=>option.onclick=()=>{$$('.option',$('#exerciseCard')).forEach(x=>x.classList.remove('selected'));option.classList.add('selected');selected=option.dataset.value});
  $('#checkAnswer').onclick=()=>{
    const raw=ex.options?selected:($('#exerciseAnswer')?.value||'');
    if(!String(raw).trim()) { $('#exerciseFeedback').innerHTML='<div class="feedback error"><strong>Falta uma resposta</strong><p>Escolha uma opção ou escreva sua tentativa antes de verificar.</p></div>'; return; }
    const accepted=ex.answers || [ex.answer];
    const clean=v=>normalizeText(String(v).trim()).replace(/\s+/g,' ');
    const correct=accepted.filter(v=>v!==undefined).some(answer=>clean(raw)===clean(answer));
    $('#exerciseFeedback').innerHTML=`<div class="feedback ${correct?'success':'error'}"><strong>${correct?'Correto — bom raciocínio.':'Ainda não.'}</strong><p>${correct?ex.explanation:`Revise o conceito e tente novamente. ${ex.explanation}`}</p>${ex.relatedLessonId?`<a class="text-link" href="${lessonHref(lessonById(ex.relatedLessonId))}">Revisar aula relacionada →</a>`:''}</div>`;
    if(correct && !state.completedExercises.includes(ex.id)) { state.completedExercises.push(ex.id); saveState(); renderHome(); }
  };
}

function renderChallenges(){
  $('#challengeGrid').innerHTML=challenges.map((c,i)=>`<article class="challenge-card"><div class="badge-row"><span class="badge">${c.tech}</span><span class="badge">${c.level}</span>${isChallengeDone(c)?'<span class="badge success-badge">Concluído</span>':''}</div><h2>${c.title}</h2><p>${c.description}</p><div class="challenge-requirements"><strong>Requisitos</strong><ul>${c.requirements.map(r=>`<li>${r}</li>`).join('')}</ul></div><div class="card-bottom"><button class="button secondary hint-button" data-id="${i}">Mostrar dica 1</button><div class="hint-box" id="hint-${i}" hidden></div><button class="text-button challenge-complete" data-id="${i}">${isChallengeDone(c)?'Desafio concluído ✓':'Marcar como concluído'}</button></div></article>`).join('');
  $$('.hint-button').forEach(btn=>{let n=0;btn.onclick=()=>{const c=challenges[Number(btn.dataset.id)],box=$(`#hint-${btn.dataset.id}`);box.hidden=false;if(n<c.hints.length){box.innerHTML=`<strong>Dica ${n+1}</strong><p>${c.hints[n]}</p>`;n++;btn.textContent=n<c.hints.length?`Mostrar dica ${n+1}`:'Mostrar solução'}else{box.innerHTML=`<strong>Solução orientadora</strong><p>${c.solution}</p>`;btn.disabled=true;btn.textContent='Solução exibida';}}});
  $$('.challenge-complete').forEach(btn=>btn.onclick=()=>{const c=challenges[Number(btn.dataset.id)];if(isChallengeDone(c))state.completedChallenges=state.completedChallenges.filter(id=>id!==c.id);else state.completedChallenges.push(c.id);saveState();renderChallenges();renderHome();});
}

function renderProjects(){
  $('#projectGrid').innerHTML=projects.map((p,i)=>{
    const steps=getProjectSteps(p),completed=isProjectDone(p),progress=projectStepProgress(p);
    return `<article class="project-card"><div class="badge-row">${p.tech.map(t=>`<span class="badge">${t}</span>`).join('')}<span class="badge">${p.level}</span></div><h2>${p.title}</h2><p>${p.description}</p><div class="project-progress"><div class="progress-label"><span>Etapas concluídas</span><strong>${progress}%</strong></div><div class="progress"><span style="width:${progress}%"></span></div></div><details class="project-details"><summary>Ver objetivo e requisitos</summary><div><h3>Objetivo</h3><p>${p.objective}</p><h3>Pré-requisitos</h3><ul>${p.prerequisites.map(x=>`<li>${x}</li>`).join('')}</ul><h3>Requisitos</h3><ul>${p.requirements.map(x=>`<li>${x}</li>`).join('')}</ul><h3>Extensões opcionais</h3><ul>${p.extensions.map(x=>`<li>${x}</li>`).join('')}</ul></div></details><div class="track-modules project-steps">${p.steps.map((step,j)=>`<label class="module-row"><span><input type="checkbox" class="project-step" data-project="${i}" data-step="${j}" ${steps[j]?'checked':''}> ${step}</span><span>${String(j+1).padStart(2,'0')}</span></label>`).join('')}</div><div class="card-bottom"><button class="button ${completed?'primary':'secondary'} project-complete" data-project="${i}">${completed?'Projeto concluído ✓':'Concluir todas as etapas'}</button></div></article>`;
  }).join('');
  $$('.project-step').forEach(input=>input.onchange=()=>{
    const project=projects[Number(input.dataset.project)],steps=getProjectSteps(project);steps[Number(input.dataset.step)]=input.checked;state.projectSteps[project.id]=steps;
    const allDone=steps.every(Boolean);if(allDone&&!isProjectDone(project))state.completedProjects.push(project.id);if(!allDone)state.completedProjects=state.completedProjects.filter(id=>id!==project.id);
    saveState();renderProjects();renderHome();if(document.body.dataset.page==='progresso')renderProgress();
  });
  $$('.project-complete').forEach(button=>button.onclick=()=>{const project=projects[Number(button.dataset.project)],completed=isProjectDone(project);state.projectSteps[project.id]=project.steps.map(()=>!completed);if(completed)state.completedProjects=state.completedProjects.filter(id=>id!==project.id);else if(!isProjectDone(project))state.completedProjects.push(project.id);saveState();renderProjects();renderHome();if(document.body.dataset.page==='progresso')renderProgress();});
}

let activeLang='html'; let pg={...defaultPlayground};
function initPlayground(){
  pg={...defaultPlayground,...(state.playground||{})};activeLang='html';updateEditor();runPlayground();
  $$('#editorTabs button').forEach(b=>b.onclick=()=>{pg[activeLang]=$('#codeEditor').value;activeLang=b.dataset.lang;$$('#editorTabs button').forEach(x=>x.setAttribute('aria-selected',x===b?'true':'false'));updateEditor()});
  $('#codeEditor').addEventListener('input',()=>{pg[activeLang]=$('#codeEditor').value;state.playground={...pg};saveState()});
  $('#runPlayground').onclick=runPlayground;
  $('#resetPlayground').onclick=()=>{pg={...defaultPlayground};state.playground={...pg};saveState();updateEditor();runPlayground()};
  $('#copyCode').onclick=()=>copyWithFeedback($('#copyCode'),$('#codeEditor').value);
}
function updateEditor(){$('#codeEditor').value=pg[activeLang]||''}
function runPlayground(){
  pg[activeLang]=$('#codeEditor')?.value??pg[activeLang];
  const doc=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${pg.css}</style></head><body>${pg.html}<script>window.onerror=function(m){document.body.insertAdjacentHTML('beforeend','<pre style="color:#b00020;background:#fff0f0;padding:12px;white-space:pre-wrap">Erro: '+String(m).replace(/</g,'&lt;')+'</pre>')};try{${pg.js}}catch(e){window.onerror(e.message)}<\/script></body></html>`;
  $('#previewFrame').srcdoc=doc;$('#runStatus').textContent='Executado agora';setTimeout(()=>$('#runStatus').textContent='Pronto',1800);state.playground={...pg};saveState();
}

let selectedTerm=glossary[0]?.term, letterFilter='Todos';
function renderGlossary(){
  if(!glossary.length) return;
  const letters=['Todos',...[...new Set(glossary.map(g=>g.term[0].toUpperCase()))]];
  $('#alphabet').innerHTML=letters.map(l=>`<button class="${letterFilter===l?'active':''}" data-letter="${l}" aria-label="${l==='Todos'?'Todos os termos':`Termos com ${l}`}">${l==='Todos'?'•':l}</button>`).join('');
  $$('#alphabet button').forEach(b=>b.onclick=()=>{letterFilter=b.dataset.letter;renderGlossary()});
  const q=normalizeText($('#glossarySearch').value||'');
  const filtered=glossary.filter(g=>(letterFilter==='Todos'||g.term[0].toUpperCase()===letterFilter)&&(!q||normalizeText(`${g.term} ${g.definition} ${g.detail}`).includes(q)));
  if(!filtered.some(g=>g.term===selectedTerm)) selectedTerm=filtered[0]?.term;
  $('#glossaryList').innerHTML=filtered.length?filtered.map(g=>`<button class="${g.term===selectedTerm?'active':''}" data-term="${escapeAttr(g.term)}">${g.term}<small>${g.category}</small></button>`).join(''):'<div class="empty-state">Nenhum termo encontrado.</div>';
  $$('#glossaryList button').forEach(b=>b.onclick=()=>{selectedTerm=b.dataset.term;history.replaceState(null,'',`#glossario/${slugify(selectedTerm)}`);renderGlossary()});
  const term=glossary.find(g=>g.term===selectedTerm);
  const related=(term?.relatedLessonIds||[]).map(lessonById).filter(Boolean);
  $('#glossaryDetail').innerHTML=term?`<span class="term-type">${term.category}</span><h2>${term.term}</h2><p class="definition">${term.definition}</p><section><h3>Entenda melhor</h3><p>${term.detail}</p></section>${related.length?`<section><h3>Aulas relacionadas</h3><div class="related-grid">${related.map(l=>`<a class="related-card" href="${lessonHref(l)}"><small>${techLabel(l.courseId)} · ${l.moduleTitle}</small><strong>${l.title}</strong></a>`).join('')}</div></section>`:''}<section><h3>Continue estudando</h3><p>Use o termo em contexto: leia a aula relacionada, altere um exemplo e depois resolva um exercício.</p><a class="button secondary" href="#trilhas">Explorar trilhas</a></section>`:'<div class="empty-state">Selecione um termo.</div>';
}

function renderProgress(){
  const total=overallProgress();
  $('#progressSummary').innerHTML=`<div class="summary-card primary"><span class="label">Progresso geral</span><strong>${total}%</strong><div class="progress"><span style="width:${total}%"></span></div></div><div class="summary-card"><span class="label">Aulas</span><strong>${state.completedLessons.filter(id=>lessonById(id)).length}</strong><span class="text-muted">de ${lessons.length}</span></div><div class="summary-card"><span class="label">Exercícios</span><strong>${state.completedExercises.length}</strong><span class="text-muted">de ${exercises.length}</span></div><div class="summary-card"><span class="label">Projetos + desafios</span><strong>${state.completedProjects.length+state.completedChallenges.length}</strong><span class="text-muted">de ${projects.length+challenges.length}</span></div>`;
  const recent=state.completedLessons.slice(-5).reverse().map(id=>lessonById(id)).filter(Boolean);
  const last=lessonById(state.lastLesson) || lessons[0]; const recommended=last?nextUncompletedLesson(last.courseId):lessons[0];
  $('#progressGrid').innerHTML=`${courses.map(c=>{const done=completedLessonsForCourse(c.id).length;return `<article class="progress-card"><div class="progress-card-head"><h2>${c.title}</h2><strong>${courseProgress(c.id)}%</strong></div><div class="progress"><span style="width:${courseProgress(c.id)}%"></span></div><div class="recent-list"><div class="recent-item"><span>Módulos</span><span>${c.modules.length}</span></div><div class="recent-item"><span>Aulas concluídas</span><span>${done}/${c.lessons}</span></div></div><a class="text-link" href="${lessonHref(nextUncompletedLesson(c.id)||firstLesson(c.id))}">${done?'Continuar':'Começar'} ${c.title} →</a></article>`}).join('')}<article class="progress-card"><div class="progress-card-head"><h2>Atividade recente</h2></div><div class="recent-list">${recent.length?recent.map(l=>`<a class="recent-item" href="${lessonHref(l)}"><span>${l.title}</span><span>${techLabel(l.courseId)}</span></a>`).join(''):'<div class="empty-state">Conclua sua primeira aula para começar o histórico.</div>'}</div></article><article class="progress-card"><div class="progress-card-head"><h2>Próximo passo</h2></div>${recommended?`<p class="text-muted">Continue em <strong>${recommended.title}</strong>, dentro de ${techLabel(recommended.courseId)} → ${recommended.moduleTitle}.</p><a class="button secondary" href="${lessonHref(recommended)}">Continuar</a>`:'<p class="text-muted">Você concluiu todo o conteúdo disponível. Revise projetos e desafios.</p>'}</article>`;
}

function initSearch(){
  const dialog=$('#searchDialog'),input=$('#globalSearch');
  const open=()=>{if(!dialog.open)dialog.showModal();setTimeout(()=>input.focus(),20);renderSearch(input.value||'')};
  $('#openSearch').onclick=open;input.addEventListener('input',()=>renderSearch(input.value));
  input.addEventListener('keydown',event=>{const links=$$('.search-result',$('#searchResults'));if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();if(!links.length)return;const current=Math.max(0,links.findIndex(link=>link.classList.contains('active')));const next=event.key==='ArrowDown'?Math.min(links.length-1,current+1):Math.max(0,current-1);links.forEach((link,index)=>link.classList.toggle('active',index===next));links[next].scrollIntoView({block:'nearest'});}if(event.key==='Enter'){const active=$('.search-result.active',$('#searchResults'))||links[0];if(active){event.preventDefault();active.click();}}});
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
  document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();open();}});
}
function renderSearch(q){
  const items=[
    ...courses.map(c=>({type:'Trilha',title:c.title,desc:`${c.modules.length} módulos · ${c.lessons} aulas`,href:firstLesson(c.id)?lessonHref(firstLesson(c.id)):'#trilhas'})),
    ...lessons.map(l=>({type:'Aula',title:l.title,desc:`${techLabel(l.courseId)} → ${l.moduleTitle}`,href:lessonHref(l)})),
    ...exercises.map(e=>({type:'Exercício',title:e.title,desc:`${e.tech} · ${e.difficulty} · ${e.type}`,href:`#exercicios/${encodeURIComponent(e.id)}`})),
    ...challenges.map(c=>({type:'Desafio',title:c.title,desc:`${c.tech} · ${c.level}`,href:'#desafios'})),
    ...projects.map(p=>({type:'Projeto',title:p.title,desc:p.tech.join(' · '),href:'#projetos'})),
    ...glossary.map(g=>({type:'Glossário',title:g.term,desc:g.definition,href:`#glossario/${slugify(g.term)}`}))
  ];
  const norm=normalizeText(q.trim());
  let results=norm?items.filter(item=>normalizeText(`${item.title} ${item.desc} ${item.type}`).includes(norm)):items.slice(0,16);
  results=results.sort((a,b)=>{if(!norm)return 0;const at=normalizeText(a.title),bt=normalizeText(b.title);const as=at===norm?0:at.startsWith(norm)?1:2;const bs=bt===norm?0:bt.startsWith(norm)?1:2;return as-bs||a.title.localeCompare(b.title,'pt-BR')}).slice(0,20);
  $('#searchResults').innerHTML=results.length?results.map((item,index)=>`<a class="search-result ${index===0?'active':''}" href="${item.href}" data-search-close><small>${item.type} · ${item.desc}</small><strong>${item.title}</strong></a>`).join(''):'<div class="empty-state">Nenhum resultado encontrado. Tente outro termo.</div>';
  $$('[data-search-close]').forEach(a=>a.onclick=()=>$('#searchDialog').close());
}

function applyTheme(theme){
  const next=theme==='light'?'light':'dark';document.documentElement.dataset.theme=next;
  const toggle=$('#themeToggle'),icon=$('#themeIcon'),meta=$('meta[name="theme-color"]');
  if(meta)meta.setAttribute('content',next==='dark'?'#090a0b':'#f6f6f3');const iconUse=icon?.querySelector('use');
  if(next==='dark'){toggle.setAttribute('aria-label','Ativar tema claro');toggle.title='Ativar tema claro';iconUse?.setAttribute('href','#icon-sun');}
  else{toggle.setAttribute('aria-label','Ativar tema escuro');toggle.title='Ativar tema escuro';iconUse?.setAttribute('href','#icon-moon');}
}
function initTheme(){applyTheme(state.theme||'dark');$('#themeToggle').onclick=()=>{state.theme=document.documentElement.dataset.theme==='dark'?'light':'dark';applyTheme(state.theme);saveState();};}
function initMobileMenu(){const btn=$('#mobileMenuButton'),nav=$('#mobileNav');const setOpen=open=>{btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',open?'Fechar menu':'Abrir menu');nav.hidden=!open;};btn.onclick=()=>setOpen(btn.getAttribute('aria-expanded')!=='true');$$('#mobileNav a').forEach(a=>a.onclick=()=>setOpen(false));document.addEventListener('keydown',event=>{if(event.key==='Escape'&&btn.getAttribute('aria-expanded')==='true')setOpen(false)});}

function init(){
  initTheme();initMobileMenu();initSearch();renderHome();renderTracks();renderExercises();renderChallenges();renderProjects();renderGlossary();initPlayground();renderProgress();route();
  $('#glossarySearch').addEventListener('input',renderGlossary);
  $('#resetProgress').onclick=()=>{if(confirm('Redefinir todo o progresso salvo neste navegador?')){state.completedLessons=[];state.completedExercises=[];state.completedChallenges=[];state.completedProjects=[];state.projectSteps={};state.lastLesson=defaultLast;saveState();renderProgress();renderHome();renderTracks();renderExercises();renderProjects();renderChallenges();}};
}
init();
