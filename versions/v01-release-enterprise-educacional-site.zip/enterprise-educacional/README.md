# Enterprise Educacional

Plataforma educacional estática, responsiva e interativa para aprender desenvolvimento e programação com aulas extensas, exemplos, exercícios, desafios, projetos, progresso local, Glossário, Busca e Playground HTML/CSS/JavaScript.

## Conteúdo atual

A expansão curricular foi organizada por dados e cobre as quatro trilhas principais:

- **HTML:** 12 módulos e 164 aulas/conteúdos;
- **CSS:** 18 módulos e 195 aulas/conteúdos;
- **JavaScript:** 25 módulos e 262 aulas/conteúdos;
- **Python:** 24 módulos e 202 aulas/conteúdos;
- **Total:** 823 aulas/conteúdos distribuídos em 79 módulos;
- **Exercícios:** 291 itens com tecnologia, dificuldade, tipo e feedback;
- **Desafios:** 24 desafios progressivos;
- **Projetos:** 31 projetos Web e Python;
- **Glossário:** 74 termos técnicos explicados em português.

O conteúdo cobre fundamentos e tópicos relevantes mais avançados, incluindo semântica e acessibilidade HTML, formulários, Flexbox, Grid, responsividade, CSS moderno, arrays, objetos, funções, DOM, eventos, assincronismo, Fetch/APIs, armazenamento local, POO, arquivos, exceções, APIs e automação em Python.

## Integração do aprendizado

- Trilhas mostram módulos, quantidade de aulas e progresso real;
- cada aula possui objetivos, explicação, sintaxe, exemplo, resultado, erros comuns, boa prática, prática e resumo;
- aulas HTML/CSS/JavaScript adequadas podem abrir o exemplo diretamente no Playground;
- exercícios podem apontar para aulas relacionadas;
- Glossário possui termos relacionados ao currículo e links para aulas quando existem correspondências;
- Busca global indexa trilhas, aulas, exercícios, desafios, projetos e Glossário;
- Progresso contabiliza todas as novas aulas e continua separado por tecnologia;
- o menu de conteúdo das aulas é recolhível no mobile para não empurrar a leitura para baixo.

## Visual

- identidade própria em escala de preto, grafite, cinza e prata;
- Dark Mode e Light Mode com superfícies e contrastes próprios;
- símbolo geométrico EE com linguagem de código;
- iconografia vetorial monocromática;
- layout desktop-first com adaptação para tablet e mobile.

## Branding

Assets principais:

- `assets/branding/enterprise-symbol.svg`
- `assets/branding/enterprise-logo-horizontal.svg`
- `assets/branding/favicon.svg`

## Estrutura

- `index.html` — estrutura global e áreas principais;
- `styles.css` — Design System, temas, componentes e responsividade;
- `content-data.js` — currículo, aulas, exercícios, desafios, projetos e Glossário;
- `app.js` — navegação, renderização, progresso, busca, filtros e Playground;
- `assets/branding/` — identidade vetorial e favicon.

## Executar localmente

Use um servidor estático para ter persistência local e comportamento consistente:

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.

O projeto não exige backend e pode ser publicado em hospedagem estática, incluindo GitHub Pages.
